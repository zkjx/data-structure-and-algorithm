import junit.framework.TestCase;

public class ComplexTest extends TestCase {
    Complex a = new Complex(1, 2);
    Complex b = new Complex(3, 4);
    Complex c = new Complex(2, 3);
    Complex d = new Complex();

    public void testComplexAdd(){
        assertEquals(new Complex(2, 2).toString(), a.ComplexAdd(new Complex(1, 0)).toString());
    }

    public void testComplexSub(){
        assertEquals(new Complex(5, 3).toString(), b.ComplexSub(new Complex(-2, 1)).toString());
    }

    public void testComplexMulti(){
        assertEquals(new Complex(-4, -3).toString(), a.ComplexMulti(new Complex(-2, 1)).toString());
    }


    public void testComeplexDiv(){
        assertEquals(new Complex(4, -3).toString(), b.ComplexDiv(new Complex(0, 1)).toString());
    }
}