import java.util.Scanner;
   
public class TempConverter
{
    public static void main(String[] args)
    {
        double A, B;  
        
        Scanner scan = new Scanner(System.in);
         
        System.out.print("输入华氏温度值: ");
        A = scan.nextDouble();
        
        B = (A - 32) / 1.8;
        
        System.out.println("对应的摄氏温度值: " + B);
    }
}

