import java.util.Scanner;
public class pp2_2
{
    public static void main(String[] args)
    {
         int  A, B, C, D;

         Scanner scan = new Scanner(System.in);

         System.out.print("Enter the number of A: ");
         A = scan.nextInt();

         System.out.print("Enter the number of B: ");
         B = scan.nextInt();

         System.out.print("Enter the number of C: ");
         C = scan.nextInt();

         D = (A+B+C) / 3;

         System.out.println("平均值= " + D);
    }
}

