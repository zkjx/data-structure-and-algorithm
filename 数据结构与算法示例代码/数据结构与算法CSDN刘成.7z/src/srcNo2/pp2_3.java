import java.util.Scanner;
public class pp2_3
{
    public static void main(String[] args)
    {
         double  A, B, C, D, E;

         Scanner scan = new Scanner(System.in);

         System.out.print("Enter the number of A: ");
         A = scan.nextDouble();

         System.out.print("Enter the number of B: ");
         B = scan.nextDouble();

         C = A + B;
         D = A - B;
         E = A * C;
      
         System.out.println("和: " + C);
         System.out.println("差: " + D);
         System.out.println("积: " + E);
    }
}

