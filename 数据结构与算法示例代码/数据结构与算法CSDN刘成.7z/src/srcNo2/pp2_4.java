import java.util.Scanner;

public class pp2_4
{ 
    public static void main(String[] args)
    {
       String name, age , college , petname ;

       Scanner scan = new Scanner(System.in);

       System.out.print("Enter your name:");
       name = scan.nextLine();

       System.out.print("Enter your age :");
       age = scan.nextLine();

       System.out.print("Enter your college :");
       college =scan.nextLine();
            
       System.out.print("Enter your petname:");
       petname = scan.nextLine();

       System.out.println(" Hello, my name is " + name + " and I am " + age + " years old. I'm enjoying my time at " + college
       + ", though I miss my pet " + petname + " very much!");
   }
}

