import java.util.Scanner;
public class pp2_8
{
    public static void main(String[] args)
    {
         int h,m,s;
	 int second;
	 final int A = 3600, B = 60;

	 Scanner scan = new Scanner(System.in);

	 System.out.print("Enter the number of hour: ");
	 h = scan.nextInt();

	 System.out.print("Enter the number of minute: ");
	 m = scan.nextInt();

	 System.out.print("Enter the number of second: ");
	 s = scan.nextInt();

	 second = A * h + B * m + s;

	 System.out.println("The number of second is : " + second);
    }
}

