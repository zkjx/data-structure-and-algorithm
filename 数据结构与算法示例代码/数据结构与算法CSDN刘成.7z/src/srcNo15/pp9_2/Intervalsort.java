package srcNo15.pp9_2;

import java.util.Arrays;

public class Intervalsort<T> {

    public static <T extends Comparable<T>>
    void Intervalsort(T[] data,int i)
    {

        for (int a =i;a>=1;a=a-2){
            for (int position=data.length-1;position>=0;position--) {
                for (int scan = 0; scan < data.length - a; scan++) {
                    if (data[scan].compareTo(data[scan + a]) > 0) {
                        swap(data, scan, scan + a);
                    }
                }
            }
        }

    }


    private static <T extends Comparable<T>>
    void swap(T[] data, int index1, int index2) {
        T temp = data[index1];
        data[index1] = data[index2];
        data[index2] = temp;
    }


}
