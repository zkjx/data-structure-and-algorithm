package srcNo15.practice181010;

public class test {
    public static void main(String[] args) {
        LinkedUnorderedList lud = new LinkedUnorderedList();
        Commodity commodity1 = new Commodity("book",10,"180910");
        Commodity commodity2 = new Commodity("bread",10,"180911");
        Commodity commodity3 = new Commodity("bread",10,"180910");
        Commodity commodity4 = new Commodity("phone",5000,"170910");
        Commodity commodity5 = new Commodity("computer",5000,"172010");
        lud.add(commodity1);
        lud.add(commodity2);
        lud.add(commodity3);
        lud.add(commodity4);
        System.out.println(lud);
        System.out.println("------------------------------------------------------------");
        lud.insert(commodity5,2);
        System.out.println(lud);
        lud.selectionSort();
        System.out.println(lud);
        lud.removeFirst();
        lud.removeLast();
        lud.remove(commodity3);
        System.out.println("----------------------------------------------------------------");
        System.out.println(lud);
        System.out.println(lud.contains(commodity1));
        System.out.println(lud.contains(commodity2));

    }
}
