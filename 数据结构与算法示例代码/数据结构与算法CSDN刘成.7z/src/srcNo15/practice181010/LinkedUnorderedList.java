package srcNo15.practice181010;

import srcNo15.exceptions.ElementNotFoundException;
import srcNo15.exceptions.EmptyCollectionException;

public class LinkedUnorderedList {
    protected int count;
    protected LinearNode<Commodity> head, tail;
    protected int modCount;


    public LinkedUnorderedList() {
        count = 0;
        head = tail = null;
        modCount = 0;
    }

    public Commodity removeFirst() throws EmptyCollectionException {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");

        LinearNode<Commodity> current = head;
        head = head.getNext();
        count--;
        modCount++;
        return current.getElement();
    }

    public Commodity removeLast() throws EmptyCollectionException {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");

        LinearNode<Commodity> current = head;
        while (current.getNext() != tail)
            current = current.getNext();
        Commodity temp = current.getNext().getElement();
        current.setNext(null);
        tail = current;
        count--;
        modCount++;
        return temp;
    }


    public Commodity remove(Commodity targetElement) throws EmptyCollectionException,
            ElementNotFoundException {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");

        boolean found = false;
        LinearNode<Commodity> previous = null;
        LinearNode<Commodity> current = head;

        while (current != null && !found)
            if (targetElement.equals(current.getElement()))
                found = true;
            else {
                previous = current;
                current = current.getNext();
            }

        if (!found)
            throw new ElementNotFoundException("LinkedList");

        if (size() == 1)
            head = tail = null;
        else if (current.equals(head))
            head = current.getNext();
        else if (current.equals(tail)) {
            tail = previous;
            tail.setNext(null);
        } else
            previous.setNext(current.getNext());

        count--;
        modCount++;

        return current.getElement();
    }

    public Commodity first() throws EmptyCollectionException {
        return head.getElement();
    }


    public Commodity last() throws EmptyCollectionException {
        return tail.getElement();
    }

    public boolean contains(Commodity targetElement) throws
            EmptyCollectionException {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");

        boolean found = false;
        LinearNode<Commodity> previous = null;
        LinearNode<Commodity> current = head;

        while (current != null && !found)
            if (targetElement.equals(current.getElement()))
                found = true;
            else {
                previous = current;
                current = current.getNext();
            }

        if (!found)
            return false;
        else
            return true;
    }

    public void add(Commodity element) {
        LinearNode<Commodity> node = new LinearNode<Commodity>(element);

        if (isEmpty())
            head = node;
        else
            tail.setNext(node);
        tail = node;
        count++;
        modCount++;

    }

    public void selectionSort() {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");
        LinearNode<Commodity> current = head;
        LinearNode<Commodity> temp,temp2,temp3 = null;
        Commodity cod = new Commodity("",0,"");
        while(current.getNext() != null) {
            temp2 = null;
            temp3 = temp = current;
            while(temp.getNext() != null){
                if(temp.getNext().getElement().compareTo(temp3.getElement()) < 0){
                    temp3 = temp2 = temp.getNext();
                    cod = temp.getNext().getElement();
                }
                temp = temp.getNext();
            }
            if(temp2 != null){
                temp2.setElement(current.getElement());
                current.setElement(cod);
            }

            current = current.getNext();
        }
    }

    public void insert(Commodity element1, int A) {
        LinearNode<Commodity> node1 = new LinearNode<Commodity>(element1);
        LinearNode<Commodity> current = head;

        if (A == 0) {
            node1.setNext(current);
            head = node1;
        } else {
            for (int i = 1; i < A; i++)
                current = current.getNext();
            node1.setNext(current.getNext());
            current.setNext(node1);
        }

        count++;
        modCount++;
    }


    public String toString() {
        int n = count;
        String result = "";
        LinearNode<Commodity> current = head;
        while (n > 0) {
            result += current.getElement() + "\n";
            current = current.getNext();
            n--;
        }
        return result;
    }

    public int size() {
        return count;
    }

    public boolean isEmpty() {
        if (count == 0)
            return true;
        else
            return false;
    }


}


