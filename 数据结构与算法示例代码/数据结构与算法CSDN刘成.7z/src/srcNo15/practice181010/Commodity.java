package srcNo15.practice181010;

public class Commodity implements Comparable<Commodity>{
    private String name;
    private int money;
    private String date;

    public Commodity(String name,int money,String date){
        this.name = name;
        this.money = money;
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public int getMoney() {
        return money;
    }

    public String getDate() {
        return date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "name='" + name + '\'' +
                ", money=" + money +
                ", date='" + date + '\'';
    }

    @Override
    public int compareTo(Commodity commodity) {
        if (name.compareTo(commodity.getName()) > 0)
            return 1;
        else{
            if (name.compareTo(commodity.getName()) < 0)
                return -1;
            else{
                if (date.compareTo(commodity.getDate()) > 0)
                    return 1;
                else
                    return -1;
            }
        }

    }
}

