package srcNo15.pp9_3;

public class test2 {
    public static void main(String[] args) {
        Integer[] list = {74, 56, 71, 90, 12, 11};
        Integer[] list2 = {74, 56, 71, 90, 12, 11};
        Integer[] list3 = {74, 56, 71, 90, 12, 11};
        Integer[] list4 = {74, 56, 71, 90, 12, 11};
        Integer[] list5 = {74, 56, 71, 90, 12, 11};

        Sorting.bubbleSort(list);
        for (int num:list)
            System.out.print(num+" ");
        System.out.println();


        Sorting.insertionSort(list2);
        for (int num:list2)
            System.out.print(num+" ");
        System.out.println();

        Sorting.mergeSort(list3);
        for (int num:list3)
            System.out.print(num+" ");
        System.out.println();

        Sorting.quickSort(list4);
        for (int num:list4)
            System.out.print(num+" ");
        System.out.println();

        Sorting.selectionSort(list5);
        for (int num:list5)
            System.out.print(num+" ");

    }
}
