package srcNo15.pp9_3;

public class test1 {
    public static void main(String[] args) {
        Integer[] list = {49, 34, 56, 72, 91, 3, 0};
        Integer[] list2 = {49, 34, 56, 72, 91, 3, 0};
        Integer[] list3 = {49, 34, 56, 72, 91, 3, 0};
        Integer[] list4 = {49, 34, 56, 72, 91, 3, 0};
        Integer[] list5 = {49, 34, 56, 72, 91, 3, 0};

        Sorting.bubbleSort(list);
        for (int num:list)
            System.out.print(num+" ");
        System.out.println();


        Sorting.insertionSort(list2);
        for (int num:list2)
            System.out.print(num+" ");
        System.out.println();

        Sorting.mergeSort(list3);
        for (int num:list3)
            System.out.print(num+" ");
        System.out.println();

        Sorting.quickSort(list4);
        for (int num:list4)
            System.out.print(num+" ");
        System.out.println();

        Sorting.selectionSort(list5);
        for (int num:list5)
            System.out.print(num+" ");

    }
}
