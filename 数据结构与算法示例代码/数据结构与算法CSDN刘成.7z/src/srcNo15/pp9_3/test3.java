package srcNo15.pp9_3;

public class test3 {
    public static void main(String[] args) {
        Integer[] list = {1, 2, 3, 4, 5};
        Integer[] list2 = {1, 2, 3, 4, 5};
        Integer[] list3 = {1, 2, 3, 4, 5};
        Integer[] list4 = {1, 2, 3, 4, 5};
        Integer[] list5 = {1, 2, 3, 4, 5};

        Sorting.bubbleSort(list);
        for (int num:list)
            System.out.print(num+" ");
        System.out.println();


        Sorting.insertionSort(list2);
        for (int num:list2)
            System.out.print(num+" ");
        System.out.println();

        Sorting.mergeSort(list3);
        for (int num:list3)
            System.out.print(num+" ");
        System.out.println();

        Sorting.quickSort(list4);
        for (int num:list4)
            System.out.print(num+" ");
        System.out.println();

        Sorting.selectionSort(list5);
        for (int num:list5)
            System.out.print(num+" ");

    }
}
