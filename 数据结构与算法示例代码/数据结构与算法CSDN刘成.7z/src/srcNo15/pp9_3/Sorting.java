package srcNo15.pp9_3;

import java.util.Arrays;


public class Sorting
{
    public static <T extends Comparable<T>>
    void selectionSort(T[] data)
    {
        long startTime=System.nanoTime();
        int min;
        T temp;
        int count= 0;

        for (int index = 0; index < data.length-1; index++)
        {
            count++;
            min = index;
            for (int scan = index+1; scan < data.length; scan++) {
                count++;
                if (data[scan].compareTo(data[min]) < 0)
                    min = scan;
            }

            swap(data, min, index);
        }
        long endTime = System.nanoTime();
        System.out.println("程序运行时间：" + (endTime - startTime) + "ns");
        System.out.println("比较次数为："+count);

    }


    private static <T extends Comparable<T>>
    void swap(T[] data, int index1, int index2)
    {
        T temp = data[index1];
        data[index1] = data[index2];
        data[index2] = temp;
    }


    public static <T extends Comparable<T>>
    void insertionSort(T[] data)
    {
        long startTime=System.nanoTime();
        int count= 0;
        for (int index = 1; index < data.length; index++)
        {
            count++;
            T key = data[index];
            int position = index;

            while (position > 0 && data[position-1].compareTo(key) > 0)
            {
                count++;
                data[position] = data[position-1];
                position--;
            }

            data[position] = key;
        }
        long endTime = System.nanoTime();
        System.out.println("程序运行时间：" + (endTime - startTime) + "ns");
        System.out.println("比较次数为："+count);
    }


    public static <T extends Comparable<T>>
    void bubbleSort(T[] data)
    {
        int position, scan;
        T temp;
        long startTime=System.nanoTime();
        int count= 0;

        for (position =  data.length - 1; position >= 0; position--)
        {
            count++;
            for (scan = 0; scan <= position - 1; scan++)
            {
                count++;
                if (data[scan].compareTo(data[scan+1]) > 0)
                    swap(data, scan, scan + 1);
            }
        }
        long endTime = System.nanoTime();
        System.out.println("程序运行时间：" + (endTime - startTime) + "ns");
        System.out.println("比较次数为："+count);
    }


    public static <T extends Comparable<T>>
    void mergeSort(T[] data)
    {
        times = times2 = 0;
        long startTime=System.nanoTime();
        mergeSort(data, 0, data.length - 1);
        long endTime = System.nanoTime();
        long temp = times + times2;
        System.out.println("程序运行时间：" + (endTime - startTime) + "ns");
        System.out.println("比较次数为："+ temp);
    }

    private static int times;
    private static <T extends Comparable<T>>
    void mergeSort(T[] data, int min, int max)
    {
        if (min < max)
        {
            times++;
            int mid = (min + max) / 2;
            mergeSort(data, min, mid);
            mergeSort(data, mid+1, max);
            merge(data, min, mid, max);
        }

    }


    private static int times2;
    @SuppressWarnings("unchecked")
    private static <T extends Comparable<T>>
    void merge(T[] data, int first, int mid, int last)
    {
        T[] temp = (T[])(new Comparable[data.length]);

        int first1 = first, last1 = mid;
        int first2 = mid+1, last2 = last;
        int index = first1;



        while (first1 <= last1 && first2 <= last2)
        {
            times2 ++;
            if (data[first1].compareTo(data[first2]) < 0)
            {
                temp[index] = data[first1];
                first1++;
                times2 ++;
            }
            else
            {
                temp[index] = data[first2];
                first2++;
                times2 ++;
            }
            index++;
        }


        while (first1 <= last1)
        {
            temp[index] = data[first1];
            first1++;
            index++;
            times2 ++;
        }


        while (first2 <= last2)
        {
            temp[index] = data[first2];
            first2++;
            index++;
            times2 ++;
        }


        for (index = first; index <= last; index++) {
            data[index] = temp[index];
            times2 ++;
        }
    }


    private static int times3;
    public static <T extends Comparable<T>>
    void quickSort(T[] data)
    {
        times3 = times4 = 0;
        long startTime=System.nanoTime();
        quickSort(data, 0, data.length - 1);
        long endTime = System.nanoTime();
        long temp = times3 + times4;
        System.out.println("程序运行时间：" + (endTime - startTime) + "ns");
        System.out.println("比较次数为："+ temp);
    }


    private static <T extends Comparable<T>>
    void quickSort(T[] data, int min, int max)
    {

        if (min < max)
        {
            times3 ++;
            int indexofpartition = partition(data, min, max);

            quickSort(data, min, indexofpartition - 1);

            quickSort(data, indexofpartition + 1, max);
        }
    }


    private static int times4;
    private static <T extends Comparable<T>>
    int partition(T[] data, int min, int max)
    {
        T partitionelement;
        int left, right;
        int middle = (min + max) / 2;

        partitionelement = data[middle];
        swap(data, middle, min);

        left = min;
        right = max;



        while (left < right)
        {
            times4++;
            while (left < right && data[left].compareTo(partitionelement) <= 0) {
                left++;
                times4++;
            }

            while (data[right].compareTo(partitionelement) > 0) {
                right--;
                times4++;
            }

            if (left < right) {
                swap(data, left, right);
                times4++;
            }
        }

        swap(data, min, right);

        return right;
    }
}
