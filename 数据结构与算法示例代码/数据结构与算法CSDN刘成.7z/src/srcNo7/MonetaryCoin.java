package srcNo7;
//***************************************************************************************
// MonetaryCoin.java               Author: Yu Kunpeng
//
//***************************************************************************************

public class MonetaryCoin extends Coin {
    private int A;
    private String B;

    public MonetaryCoin() {
        super();
        A = face;

    }

    public String returnmianzhi() {
        if (face == 0)
            B = "Heads";
        else
            B = "Tails";
        return B;
    }

}
