package srcNo7;

public class Dictionary extends Book {
    private int definitions = 52500;

    //------------------------------------------------------------------------------------------------
    // Prints a message using both local and inher ited values
    //------------------------------------------------------------------------------------------------
    public double computerRatio() {
        return (double) definitions / pages;
    }

    //------------------------------------------------------------------------------------------------
    // Definitions  nutator
    //------------------------------------------------------------------------------------------------
    public void setDefinitions(int numDefinitions) {
        definitions = numDefinitions;
    }

    //------------------------------------------------------------------------------------------------
    // Definitions    accessor
    //------------------------------------------------------------------------------------------------
    public int getDefinitions() {
        return definitions;
    }


}
