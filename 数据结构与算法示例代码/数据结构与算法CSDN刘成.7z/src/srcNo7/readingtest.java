package srcNo7;

//**********************************************************************
//  readingtest.java                         Author: Yu Kunpeng
//
//**********************************************************************
public class readingtest {
    public static void main(String[] args) {
        books A = new books(35, "star");
        A.setName("tushu");
        A.setAuthor("ykp");
        System.out.println(A);
        System.out.println();

        novel B = new novel(50, "story");
        B.setName("xiaoshuo");
        B.setAuthor("ykp");
        System.out.println(B);
        System.out.println();

        magazine C = new magazine(65, "zuowen");
        C.setName("zazhi");
        C.setAuthor("ykp");
        System.out.println(C);
        System.out.println();

        academicjournal D = new academicjournal(60, "zhuanye");
        D.setName("xueshukanwu");
        D.setAuthor("ykp");
        System.out.println(D);
        System.out.println();

        textbook E = new textbook(100, "study");
        E.setName("keben");
        E.setAuthor("ykp");
        System.out.println(E);
        System.out.println();


    }
}
