package srcNo7;

//*****************************************************************************************
// Book2.java        Author: Yu Kunpeng
//
// Represents a book. Used as the parent of a derived class to
// demonstate inheritance and the use of the super reference.
//*****************************************************************************************
public class Book2 {
    protected int pages;

    //------------------------------------------------------------------------------------
    // Constructor: Sets up the book with the specofied  number of  pages
    //------------------------------------------------------------------------------------
    public Book2(int numPages) {
        pages = numPages;
    }

    //------------------------------------------------------------------------------------
    // Pages mutator
    //------------------------------------------------------------------------------------
    public void setPages(int numPages) {
        pages = numPages;
    }

    //------------------------------------------------------------------------------------
    //  Pages accessor
    //------------------------------------------------------------------------------------
    public int getPages() {
        return pages;
    }

}
