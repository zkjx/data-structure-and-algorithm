package srcNo7;

//**********************************************************************************
//   readingmaterial                Author: Yu Kunpeng
//
//***********************************************************************************
public class readingmaterial {
    protected int page;
    protected String keywords;

    public readingmaterial(int A, String B) {
        page = A;
        keywords = B;

    }

}
