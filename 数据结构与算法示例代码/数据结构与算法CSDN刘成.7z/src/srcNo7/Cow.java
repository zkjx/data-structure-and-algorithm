package srcNo7;

//**************************************************************************************
// Cow.java                                    Author:Yu Kunpeng
//
//**************************************************************************************
public class Cow extends Animal {
    String A, B, C;

    public Cow(String name, int id) {
        super(name, id);
    }

    public void eat() {
        A = "我爱吃草";
    }

    public String getEat() {
        return A;
    }

    public void setEat(String a) {
        A = a;
    }

    public void sleep() {
        B = "我在牛圈睡觉";
    }

    public String getSleep() {
        return B;
    }

    public void setSleep(String b) {
        B = b;
    }

    public void introduction() {
        C = "我叫" + name;

    }

    public String getIntroduction() {
        return C;
    }

    public void setIntroduction(String c) {
        C = c;
    }

    public String toString() {
        return id + A + B + C;
    }

}
