package srcNo7;

//***********************************************************************************************
//  MonetaryCoinTest.java            Author:Yu Kunpeng
//
//***********************************************************************************************
public class MonetaryCoinTest {
    public static void main(String[] args) {
        int A = 0, B = 0;
        String C, D, E, F;

        MonetaryCoin a = new MonetaryCoin();
        MonetaryCoin b = new MonetaryCoin();
        MonetaryCoin c = new MonetaryCoin();
        MonetaryCoin d = new MonetaryCoin();

        C = a.returnmianzhi();
        D = b.returnmianzhi();
        E = c.returnmianzhi();
        F = d.returnmianzhi();

        System.out.println(C + "\t" + D + "\t" + E + "\t" + F);

        if (a.isHeads())
            A++;
        else
            B++;

        if (b.isHeads())
            A++;
        else
            B++;

        if (c.isHeads())
            A++;
        else
            B++;

        if (d.isHeads())
            A++;
        else
            B++;

        System.out.println("该硬币正面朝上的次数为: " + A);
        System.out.println("该硬币反面朝上的次数为: " + B);
    }
}
