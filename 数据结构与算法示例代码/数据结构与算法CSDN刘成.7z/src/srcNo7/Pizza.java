package srcNo7;

//******************************************************************************
public class Pizza extends FoodItem {
    public Pizza(int fatGrams) {
        super(fatGrams, 8);
    }

}
