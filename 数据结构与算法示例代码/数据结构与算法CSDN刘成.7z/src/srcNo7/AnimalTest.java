package srcNo7;

import java.awt.print.Book;

//****************************************************************************************
//  AnimalTest.java                    Author:Yu Kunpeng
//
//****************************************************************************************
public class AnimalTest {
    public static void main(String[] args) {
        Cow A = new Cow("哞哞", 1001);
        Sheep B = new Sheep("咩咩", 1002);
        A.eat();
        A.sleep();
        A.introduction();
        B.eat();
        B.sleep();
        B.introduction();

        System.out.println(A);
        System.out.println(B);

        A.setEat("我不吃草");
        A.setSleep("我不在牛圈睡觉");
        A.setIntroduction("我不叫哞哞");
        System.out.println(A.getEat() + A.getSleep() + A.getIntroduction());

        B.setEat("我不吃草");
        B.setSleep("我不在羊圈睡觉");
        B.setIntroduction("我不叫咩咩");
        System.out.println(B.getEat() + B.getSleep() + B.getIntroduction());


    }
}
