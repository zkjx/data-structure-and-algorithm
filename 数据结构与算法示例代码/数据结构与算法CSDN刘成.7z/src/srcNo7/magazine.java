package srcNo7;

//******************************************************************************************
// magazine.java                                 Author:Yu Kunpeng
//
//******************************************************************************************
public class magazine extends readingmaterial {
    String name, author;

    public magazine(int A, String B) {
        super(A, B);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public String toString() {
        String Z = page + "\t" + keywords + "\t" + name + "\t" + author;
        return Z;
    }
}
