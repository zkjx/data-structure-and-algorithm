package srcNo7;

//************************************************************************
//  academicjournal.java                         Author: Yu Kunpeng
//
//***********************************************************************
public class academicjournal extends readingmaterial {
    String name, author;

    public academicjournal(int A, String B) {
        super(A, B);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public String toString() {
        String Z = page + "\t" + keywords + "\t" + name + "\t" + author;
        return Z;
    }
}
