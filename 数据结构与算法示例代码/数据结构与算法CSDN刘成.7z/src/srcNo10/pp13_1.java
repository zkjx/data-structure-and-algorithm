package srcNo10;
/*
    pp13_1.java              Author:Yu Kunpeng
 */

import java.text.NumberFormat;

public class pp13_1 {
    private DVD519[] collection;
    private int count;
    private double totalCost;
    private DVD519Node list;

    //----------------------------------------------------------------------
    //  Constructor: Creates an intially empty collection.
    //--------------------------------------------------------------------
    public pp13_1() {
        collection = new DVD519[100];
        count = 0;
        totalCost = 0.0;
    }

    //-------------------------------------------------------------------------------------
    //  Adds a DVD to the collection, increasing the size of the collection array if
    //  necessary .
    //------------------------------------------------------------------------------------
    public void add(DVD519 mag)
    {
        DVD519Node node = new DVD519Node(mag);
        DVD519Node current;

        if (list == null)
            list = node;
        else
        {
            current = list;
            while (current.next != null)
                current = current.next;
            current.next = node;
        }
    }

    //----------------------------------------------------------------------------------------------------
    //Returns a report describing the DVD collection.
    //----------------------------------------------------------------------------------------------------
    public String toString() {
        String result = "";

        DVD519Node current = list;

        while (current != null)
        {
            result += current.dvd + "\n";
            current = current.next;
        }

        return result;
    }

    public class DVD519Node {
        public DVD519 dvd;
        public DVD519Node next;

        //--------------------------------------------------------------
        //  Sets up the node
        //--------------------------------------------------------------
        public DVD519Node(DVD519 mag)
        {
            dvd = mag;
            next = null;
        }

        public DVD519 getDvd()
        {
            return dvd;
        }

    }
}
