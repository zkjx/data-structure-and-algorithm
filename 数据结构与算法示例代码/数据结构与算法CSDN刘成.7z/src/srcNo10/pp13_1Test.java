package srcNo10;
/*
          pp13_1Test.java                  Author:Yu Kunpeng
 */
public class pp13_1Test {
    public static void main(String[] args) {
        pp13_1 movies = new pp13_1();
        DVD519 A = new DVD519("The Godfather", "Francis Ford Coppola", 1972, 24.95, true);
        DVD519 B = new DVD519("District 9", "Neill Blomkamp", 2009, 19.95, false);
        DVD519 C = new DVD519("Iron Man", "Jon Favreau", 2008, 15.95, false);
        DVD519 D = new DVD519("All About Eve", "Joseph Mankiewicz", 1950, 17.50, false);
        DVD519 E = new DVD519("The Matrix", "Andy & Lana Wachowski", 1999, 19.95, true);

        movies.add(A);
        movies.add(B);
        movies.add(C);
        movies.add(D);
        movies.add(E);

        System.out.println(movies);

    }

}
