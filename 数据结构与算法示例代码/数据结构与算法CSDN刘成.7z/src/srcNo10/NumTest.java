package srcNo10;

public class NumTest {
    public static void main(String[] args) {
        Num A = new Num();

        A.add(new Number(2));
        A.add(new Number(1));
        A.add(new Number(5));
        A.add(new Number(9));
        A.add(new Number(18));
        A.add(new Number(0));
        A.add(new Number(11));

        A.sort();

    }
}
