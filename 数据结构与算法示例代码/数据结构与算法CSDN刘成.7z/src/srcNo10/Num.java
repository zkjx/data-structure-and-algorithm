package srcNo10;

import java.util.ArrayList;

public class Num {
    private NumNode list;

    public Num()
    {
        list = null;
    }

    public void add(Number mag)
    {
        NumNode node = new NumNode(mag);
        NumNode current;

        if (list == null)
            list = node;
        else
        {
            current = list;
            while (current.next != null)
                current = current.next;
            current.next = node;
        }
    }
    public String toString()
    {
        String result = "";

        NumNode current = list;

        while (current != null)
        {
            result += current.number + "\n";
            current = current.next;
        }

        return result;
    }

    public void selectionSort(Comparable[] list) {
        for (int index = 1; index < list.length; index++) {
            Comparable key = list[index];
            int position = index;

            while (position > 0 && key.compareTo(list[position-1])< 0) {
                list[position] = list[position - 1];
                position--;
            }

            list[position] = key;
        }
    }

    public void sort(){
        NumNode current = list;

        ArrayList<Number> band = new ArrayList<Number>();
        while (current.next != null) {
            band.add(current.getNumber());
            current = current.next;
        }
        band.add(current.getNumber());


        Number[] list = new Number[band.size()];
        for (int i = 0;i<band.size();i++)
            list[i] = band.get(i);

        selectionSort(list);

        for (int j = 0;j<list.length;j++)
            System.out.println(list[j]);

    }


    public class NumNode {
        public  Number number;
        public NumNode next;

        //--------------------------------------------------------------
        //  Sets up the node
        //--------------------------------------------------------------
        public NumNode(Number mag)
        {
            number = mag;
            next = null;
        }

        public Number getNumber()
        {
            return number;
        }

    }
}
