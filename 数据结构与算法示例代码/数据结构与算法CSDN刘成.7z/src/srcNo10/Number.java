package srcNo10;

public class Number implements Comparable {
    private int A;


    public Number(int B) {
        A = B;
    }

    public int getA() {
        return A;
    }

    public String toString() {
        return A + "";
    }

    @Override
    public int compareTo(Object o) {
        int result;

        String C = ((Number) o).toString();
        result = Integer.parseInt(toString())-(Integer.parseInt(C));

        return result;
    }
}



