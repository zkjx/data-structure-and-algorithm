package srcNo10;

import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Complex2Test extends TestCase {
    Complex2 a = new Complex2(1, 2);
    Complex2 b = new Complex2(1, -4);
    Complex2 c = new Complex2(19, 0);
    Complex2 d = new Complex2(0, -3);
    Complex2 e = new Complex2(0, 0);

    @Before
    public void before() throws Exception {
    }

    @After
    public void after() throws Exception {
    }

    /**
     * Method: getRealPart()
     */

    @Test
    public void testEquals() throws Exception {
//TODO: Test goes here...
        assertEquals(true, c.equals(19, 0));
        assertEquals(false, d.equals(0, 0));
    }
    @Test
    public void testComplexAdd() throws Exception {
//TODO: Test goes here...
        assertEquals("2.0-2.0i", a.ComplexAdd(b));
    }
    @Test
    public void testComplexSub() throws Exception {
//TODO: Test goes here...
        assertEquals("0.0+6.0i", a.ComplexSub(b));
    }

    @Test
    public void testComplexMulti() throws Exception {
//TODO: Test goes here...
        assertEquals("9.0-2.0i", a.ComplexMulti(b));
    }
    @Test
    public void testComplexDiv() throws Exception {
//TODO: Test goes here...
        assertEquals("-0.4117647058823529+0.02076124567474049i", a.ComplexDiv(b));
    }


}