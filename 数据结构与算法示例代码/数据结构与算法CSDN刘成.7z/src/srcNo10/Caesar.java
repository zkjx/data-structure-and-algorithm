package srcNo10;
/*
   Caesar.java                  Author:Yu Kunpeng
 */

/**
 * @author Yu Kunpeng
 */
public class Caesar {
    public static void main(String[] args) throws Exception{
        String s=args[0];
        int key=Integer.parseInt(args[1]);
        String es="";
        for(int i=0;i<s.length( );i++)
        {  char c=s.charAt(i);
            // 是小写字母
            if(c>='a' && c<='z')
            //移动key%26位
            { c+=key%26;
                if(c<'a') {
                    //向左超界
                    c+=26;
                }
                if(c>'z') {
                    //向右超界
                    c-=26;
                }
            }
            // 是大写字母
            else if(c>='A' && c<='Z')
            {  c+=key%26;
                if(c<'A') {
                    c+=26;
                }
                if(c>'Z') {
                    c-=26;
                }
            }
            es+=c;
        }
        System.out.println(es);
    }
}
