package img;

public class zxc {
    public static void main(String[] args){
        System.out.println("asd");
    }
}
