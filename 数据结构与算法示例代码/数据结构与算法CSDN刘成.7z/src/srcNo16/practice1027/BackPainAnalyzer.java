package srcNo16.practice1027;


import java.io.FileNotFoundException;

/**
 * BackPainAnaylyzer demonstrates the use of a binary decision tree to 
 * diagnose back pain.
 */
public class BackPainAnalyzer
{
    /**
     *  Asks questions of the user to diagnose a medical problem.
     */
    public static void main (String[] args) throws FileNotFoundException
    {
        System.out.println ("So, you're having back pain.");

        DecisionTree expert = new DecisionTree("input.txt");
        expert.evaluate();
        System.out.println("该树的叶子结点个数为" + expert.Countleaf());
        System.out.println("该树的深度为"+expert.Height() );

        System.out.println(expert.traverse());
        System.out.println();
        System.out.println(expert.traverse2());
    }
}
