package srcNo16.HashPractice;

public class test {
    public static void main(String[] args) {
        int[] a = new int[]{11, 78, 10, 1, 3, 2, 4, 21, 34};
        HashSearch hs = new HashSearch(a,9);
        hs.createHashTable();
        System.out.println(hs.contains(14));
        System.out.println(hs.contains(15));
        System.out.println(hs.contains(11));
        System.out.println("ASL的值为："+ hs.aslNum());
        System.out.println("冲突的次数为"+hs.getConflict());
    }
}
