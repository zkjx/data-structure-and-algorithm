package srcNo16.HashPractice;

public class HashSearch {
    LinearNode[] hashtable;
    int[] temp;
    int num, num2,conflict;

    public HashSearch(int[] data, int p){
        num2 = p;
        temp = data;
        num = Prime(p);
        hashtable = new LinearNode[(int)(p/0.6)+1];
    }

    public LinearNode[] createHashTable() {
        int k;
        for (int i = 0; i < num2; i++) {
            LinearNode node = new LinearNode();
            node.setElement(temp[i]);
            k = temp[i] % num;
            if (hashtable[k] == null) {
                hashtable[k] = node;
            }else {
                LinearNode current = hashtable[k];
                while (current.getNext() != null) {
                    current = current.getNext();
                }
                current.setNext(node);
            }
        } return hashtable;
    }

    public boolean isPrimes(int n) {
        for(int i = 2; i <= Math.sqrt(n); i++ ) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public double aslNum(){
        double result = 0;
        int A = 0;
         for(int i = 0;i < hashtable.length;i++){
             LinearNode temp2 = hashtable[i];
             A = 1;
             while(temp2 != null){
                 if(A >= 2)
                     conflict++;
                 result = result + A;
                 temp2 = temp2.getNext();
                 A++;
             }
         }

         return result/num2;
    }

    public int Prime(int a){
        int A = ((int)(1.1*a)+1);
        boolean isprime = false;
        for(;A < 1.7*a;A++){
            if(isPrimes(A))
                return A;
        }
        return ((int)(1.7*a));

    }

    public boolean contains(int a){
        int temp = a % num;
        LinearNode current = new LinearNode();
        current = hashtable[temp];
        while(current != null){
            if(current.getElement() == (Integer)a)
                return true;
            else
                current= current.getNext();
        }
        return false;


    }

    public int getConflict(){
        return conflict;
    }

}
