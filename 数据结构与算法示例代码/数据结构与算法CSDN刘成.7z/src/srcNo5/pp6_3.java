//*******************************************************************************
// pp6_3.java                       Author: Yu Kunpeng
//
//*******************************************************************************

public class pp6_3
{
    public static void main(String[] args)
    {
        int num1 = 1;
        
        for (num1 = 1; num1 <=12; num1 ++)
        {
            for (int num2 = 1; num2 <= num1; num2 ++)
            { 
                System.out.print(num1 + "*" + num2 + "="  + num1 * num2 + " ");
            }
            
            System.out.print("\n");
        }
    }
}


