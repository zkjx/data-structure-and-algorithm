//*************************************************************************************************
// pp5_3.java                             Author:Yu Kunepeng
//
//*************************************************************************************************
import java.util.*;
import java.io.*;

public class pp5_3
{
    public static void main(String[] args)
    {
        char num2;
        int num1, num3 = 0, num4, A = 0, B = 0, C = 0;
        double D;
        String num, zxc;
         
        System.out.println("请输入一个整数: ");
        Scanner scan = new Scanner(System.in);
        num = scan.nextLine();

      
        num1 = num.length();
         
        while (num3 < num1)
        {   
            int E;
            num2 = num.charAt(num3);
            zxc = ("" + num2 + "");
            num4 = Integer.parseInt(zxc);
            System.out.println(num4);
            D = num4 * 1.0 / 2;
            E = (int) D;
            if (num4 == 0)
               C++ ;
            else
                if (E == D)
                    A++ ;
                else
                    B++ ;
            num3++;
        }

        System.out.println("该整数中包含的零数字个数为: " + C);
        System.out.println("该整数中包含的奇数字个数为: " + B);
        System.out.println("该整数中包含的偶数字个数为: " + A);
    }
}





       
