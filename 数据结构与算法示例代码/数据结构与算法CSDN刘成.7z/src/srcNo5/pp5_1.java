//*************************************************************************************
// pp5_1.java      Author:Yu Kunpeng
//
//*************************************************************************************
import java.util.Scanner;

public class pp5_1
{
    public static void main(String[] args)
    {
        int num, num1, num6, num7, num8;
        double num3, num4, num5;

        Scanner scan = new Scanner(System.in);

        System.out.println("请输入一个年份: ");
        num1 = scan.nextInt();

        if (num1 > 1582)
        {
            num = num1;
             
            num3 = num * 1.0 / 4;
            num4 = num * 1.0 / 100;
            num5 = num * 1.0 / 400;
                        
            num6 = (int) num3;
            num7 = (int) num4;
            num8 = (int) num5;
                    
            if (num7 == num4)
                if (num8 == num5)
                    System.out.println("该年是闰年");
                else
                    System.out.println("该年不是闰年");
            else
                if (num6 == num3)
                    System.out.println("该年是闰年");
                else
                    System.out.println("该年不是闰年");
        }
        else
            System.out.println("该数无效");

    }
}




        


            
           
