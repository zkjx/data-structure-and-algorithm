//***********************************************************************************************
// CountFlips.java                          Author:Yu Kunpeng
//
//***********************************************************************************************
public class CountFlips
{
    public static void main(String[] args)
    {
        int A = 0;
                 
        Coin mycoin = new Coin();
        
        for (int i = 0; i < 100; i++)
        {
            mycoin.flip();
            if (mycoin.isHeads())
                A++;
        }

        System.out.println("硬币朝上的次数为" + A);
    }
}

   
