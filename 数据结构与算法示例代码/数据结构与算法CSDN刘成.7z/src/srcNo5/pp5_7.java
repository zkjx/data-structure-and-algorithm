//*********************************************************************
// pp5_7.java        Author:Yu Kunpeng
//
//*********************************************************************
import java.util.Scanner;

public class pp5_7
{
    public static void main(String[] args)
    {   
        int num2 = 0, num3 = 0, num4 = 0, B;
        String another = "y";

        
        Scanner scan = new Scanner(System.in);

        double num1;

        while (another.equalsIgnoreCase("y"))
        {
           num1 = Math.random() * 3;

           System.out.println("choose shitou enter 0; choose jiandao enter 1; choose bu enter 2: ");
           B = scan.nextInt();

           if (num1 < 1)
               if (B == 0)
                {
                   System.out.println("计算机选择了shitou\n和局");
                   num2 ++;
                }
               else
                   if (B == 1)
                   {
                       System.out.println("计算机选择了shitou\n你输了");
                       num3 ++;
                   }
                    else
                    {
                        System.out.println("计算机选择了shitou\n你赢了");
                        num4 ++;
                    }
            else
                    if (num1 < 2)
                       if (B == 1)
                        { 
                           System.out.println("计算机选择了jiandao\n和局");
                           num2 ++;
                        }
                       else
                           if (B == 2) 
                           {
                               System.out.println("计算机选择了jiandao\n你输了");
                               num3 ++;
                           }
                            else
                           {
                            System.out.println("计算机选择了jiandao\n你赢了");
                            num4 ++;
                           }
               
                    else
                       if (B == 2)
                       {
                           System.out.println("计算机选择了bu\n和局");
                           num2 ++;
                       }
                       else
                         if (B == 0)
                         {
                            System.out.println("计算机选择了bu\n你输了");
                            num3 ++;
                         } 
                         else
                         {
                             System.out.println("计算机选择了bu\n你赢了");
                             num4 ++;
                         }

            System.out.println();
            System.out.print("Test another (y/n)? ");
            another = scan.nextLine();
            another = scan.nextLine(); 
           } 
            System.out.println();           
            System.out.println("和局的次数为: " + num2);
            System.out.println("输的次数为: " + num3);
            System.out.println("赢的次数为: " + num4);
    }
}

                 




