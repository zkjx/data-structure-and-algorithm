package srcNo20;

import junit.framework.TestCase;
import org.junit.Test;

import static org.junit.Assert.*;

public class SortingProTest extends TestCase {
    @Test
    public void testSearch() throws Exception {
        int cpb[] = {5, 2, 1, 3, 0};
        String expect1 = 0 + " " + 1 + " " + 2 + " " + 3 + " " + 5 + " ";
        String expect2 = 0 + " " + 1 + " " + 2 + " " + 3 + " " + 4 + " " + 5 + " ";
        SortingPro sp = new SortingPro();

        //正常
        assertEquals(expect1,sp.shellSort(cpb));
        assertEquals(expect1,sp.binaryTreesort(cpb));
        assertEquals(expect1,sp.bubbleSort(cpb));
        assertEquals(expect1,sp.heapSort(cpb));
        assertEquals(expect1,sp.mergeSort(cpb));
        assertEquals(expect1,sp.quickSort(cpb));
        assertEquals(expect1,sp.selectionSort(cpb));

        //异常
        assertNotEquals(expect2,sp.shellSort(cpb));
        assertNotEquals(expect2,sp.binaryTreesort(cpb));
        assertNotEquals(expect2,sp.bubbleSort(cpb));
        assertNotEquals(expect2,sp.heapSort(cpb));
        assertNotEquals(expect2,sp.mergeSort(cpb));
        assertNotEquals(expect2,sp.quickSort(cpb));
        assertNotEquals(expect2,sp.selectionSort(cpb));

    }
}