package srcNo20;

import junit.framework.TestCase;
import org.junit.Test;

import static org.junit.Assert.*;

public class SearchingProTest extends TestCase {
    @Test
    public void testSearch() throws Exception {
        int cpb[] = {20, 30, 40, 50, 60, 70};
        int cpb2[] = {30, 50, 70};
        SearchingPro sp = new SearchingPro();
        assertEquals(0,sp.LinearSearch(cpb,20));//边界
        assertEquals(0,sp.binarySearch(cpb,20));//边界
        assertEquals(0,sp.sequenceSearch(cpb,20));//边界
        assertEquals(0,sp.InsertionSearch(cpb,20,0,4));//边界
        assertEquals(0,sp.fbSearch(cpb,20));//边界
        assertEquals(0,sp.blockSearch(cpb2,cpb,20,2));//边界
        assertEquals(true,sp.binaryTreeSearch(cpb,20));//边界
        assertEquals(0,sp.hashsearch(cpb,20));//边界

        assertEquals(2,sp.LinearSearch(cpb,40));//正常
        assertEquals(2,sp.binarySearch(cpb,40));//正常
        assertEquals(2,sp.sequenceSearch(cpb,40));//正常
        assertEquals(2,sp.InsertionSearch(cpb,40,0,4));//正常
        assertEquals(2,sp.fbSearch(cpb,40));//正常
        assertEquals(2,sp.blockSearch(cpb2,cpb,40,2));//正常
        assertEquals(true,sp.binaryTreeSearch(cpb,40));//正常
        assertEquals(2,sp.hashsearch(cpb,40));//正常

        assertEquals(-1,sp.LinearSearch(cpb,100));//异常
        assertEquals(-1,sp.binarySearch(cpb,100));//异常
        assertEquals(-1,sp.sequenceSearch(cpb,100));//异常
        assertEquals(-1,sp.blockSearch(cpb2,cpb,100,2));//异常
        assertEquals(-1,sp.fbSearch(cpb,100));//异常
        assertEquals(-1,sp.hashsearch(cpb,100));//异常


    }
}