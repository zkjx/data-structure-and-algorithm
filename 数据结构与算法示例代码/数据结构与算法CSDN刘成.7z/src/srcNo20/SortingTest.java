package srcNo20;

import junit.framework.TestCase;
import org.junit.Test;

import static org.junit.Assert.*;

public class SortingTest extends TestCase {

    @Test
    public void testInsertionSort() throws Exception{
        String expect = 11+" "+18+" "+19+" "+20+" "+2313+" ";
        String expect2 = 1+" "+2+" "+3+" "+4+" "+5+" ";
        String expect3 = 5+" "+4+" "+3+" "+2+" "+1+" ";
        String expect4 = "B" +" "+"D"+" "+"E"+" "+"G"+" "+"C"+" ";
        String expect5 = "A" +" "+"B"+" "+"C"+" "+"D"+" "+"E"+" ";
        String expect6 = "E" +" "+"D"+" "+"C"+" "+"B"+" "+"A"+" ";
        String expect7 = "B" +" "+"C"+" "+"D"+" "+"E"+" "+"G"+" ";

        Comparable cpb[] = { 20,18,11,19,2313};//正常
        assertEquals(expect,Sorting.insertionSort(cpb));//正常
        assertNotEquals(expect2,Sorting.insertionSort(cpb));//异常

        Comparable cpb2[] = { 1,2,3,4,5};//正序
        assertEquals(expect2,Sorting.insertionSort(cpb2));//正常
        assertNotEquals(expect,Sorting.insertionSort(cpb2));//异常

        Comparable cpb3[] = { 5,4,3,2,1};//倒序
        assertEquals(expect2,Sorting.insertionSort(cpb3));//正常
        assertNotEquals(expect,Sorting.insertionSort(cpb3));//异常

        Comparable cpb4[] = {"B","D","E","G","C"};//正常
        assertEquals(expect7,Sorting.insertionSort(cpb4));//正常
        assertNotEquals(expect4,Sorting.insertionSort(cpb4));//异常

        Comparable cpb5[] = {"A","B","C","D","E"};//正序
        assertEquals(expect5,Sorting.insertionSort(cpb5));//正常
        assertNotEquals(expect6,Sorting.insertionSort(cpb5));//异常

        Comparable cpb6[] = {"E","D","C","B","A"};//正序
        assertEquals(expect5,Sorting.insertionSort(cpb6));//正常
        assertNotEquals(expect6,Sorting.insertionSort(cpb6));//异常
    }

}