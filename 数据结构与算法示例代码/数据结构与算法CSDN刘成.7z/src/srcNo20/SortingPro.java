package srcNo20;

import srcNo17.pp11_8.LinkedBinarySearchTree;
import srcNo18.pp12_8.ArrayHeap;

import java.util.StringTokenizer;

public class SortingPro {
    //希尔排序
    public String shellSort(int[] data) {
        int j = 0;
        int temp = 0;
        //每次将increment缩短为原来的一半
        for (int increment = data.length / 2; increment > 0; increment /= 2) {
            for (int i = increment; i < data.length; i++) {
                temp = data[i];
                for (j = i; j >= increment; j -= increment) {
                    if (temp < data[j - increment]) {
                        data[j] = data[j - increment];
                    } else {
                        break;
                    }
                }
                data[j] = temp;
            }
        }
        return toString(data);
    }

    //堆排序
    public String heapSort(int[] data) {
        ArrayHeap ah = new ArrayHeap();
        for (int i = 0; i < data.length; i++)
            ah.addElement(data[i]);
        for (int j = 0; j < data.length; j++) {
            data[j] = (int) ah.removeMin();
        }
        return toString(data);
    }


    //二叉树排序
    public String binaryTreesort(int[] data) {
        LinkedBinarySearchTree lbst = new LinkedBinarySearchTree();
        for (int i = 0; i < data.length; i++) {
            lbst.addElement(data[i]);
        }
        for (int j = 0; j < data.length; j++) {
            data[j] = (int) lbst.removeMin();
        }
        return toString(data);
    }

    //选择排序
    public String selectionSort(int[] data) {
        int min;
        int temp;

        for (int index = 0; index < data.length - 1; index++) {
            min = index;
            for (int scan = index + 1; scan < data.length; scan++)
                if (data[scan] < (data[min]))
                    min = scan;

            swap(data, min, index);
        }
        return toString(data);
    }

    //交换两元素
    private static <T extends Comparable<T>>
    void swap(int[] data, int index1, int index2) {
        int temp = data[index1];
        data[index1] = data[index2];
        data[index2] = temp;
    }


    //插入排序
    public void insertionSort(int[] data) {
        for (int index = 1; index < data.length; index++) {
            int key = data[index];
            int position = index;

            while (position > 0 && data[position - 1] > (key)) {
                data[position] = data[position - 1];
                position--;
            }

            data[position] = key;
        }
    }


    //冒泡排序
    public String bubbleSort(int[] data) {
        int position, scan;
        int temp;

        for (position = data.length - 1; position >= 0; position--) {
            for (scan = 0; scan <= position - 1; scan++) {
                if (data[scan] > (data[scan + 1]))
                    swap(data, scan, scan + 1);
            }
        }
        return toString(data);
    }


    //归并排序
    public String mergeSort(int[] data) {
        mergeSort(data, 0, data.length - 1);
        return toString(data);
    }


    private void mergeSort(int[] data, int min, int max) {
        if (min < max) {
            int mid = (min + max) / 2;
            mergeSort(data, min, mid);
            mergeSort(data, mid + 1, max);
            merge(data, min, mid, max);
        }
    }


    @SuppressWarnings("unchecked")
    private void merge(int[] data, int first, int mid, int last) {
        int[] temp = new int[data.length];

        int first1 = first, last1 = mid;  // endpoints of first subarray
        int first2 = mid + 1, last2 = last;  // endpoints of second subarray
        int index = first1;  // next index open in temp array

        //  Copy smaller item from each subarray into temp until one
        //  of the subarrays is exhausted
        while (first1 <= last1 && first2 <= last2) {
            if (data[first1] < (data[first2])) {
                temp[index] = data[first1];
                first1++;
            } else {
                temp[index] = data[first2];
                first2++;
            }
            index++;
        }

        //  Copy remaining elements from first subarray, if any
        while (first1 <= last1) {
            temp[index] = data[first1];
            first1++;
            index++;
        }

        //  Copy remaining elements from second subarray, if any
        while (first2 <= last2) {
            temp[index] = data[first2];
            first2++;
            index++;
        }

        //  Copy merged data into original array
        for (index = first; index <= last; index++)
            data[index] = temp[index];
    }


    //快速排序
    public String quickSort(int[] data) {
        quickSort(data, 0, data.length - 1);
        return toString(data);
    }


    private void quickSort(int[] data, int min, int max) {
        if (min < max) {
            // create partitions
            int indexofpartition = partition(data, min, max);

            // sort the left partition (lower values)
            quickSort(data, min, indexofpartition - 1);

            // sort the right partition (higher values)
            quickSort(data, indexofpartition + 1, max);
        }
    }


    private int partition(int[] data, int min, int max) {
        int partitionelement;
        int left, right;
        int middle = (min + max) / 2;

        // use the middle data value as the partition element
        partitionelement = data[middle];
        // move it out of the way for now
        swap(data, middle, min);

        left = min;
        right = max;

        while (left < right) {
            // search for an element that is > the partition element
            while (left < right && data[left] <= (partitionelement))
                left++;

            // search for an element that is < the partition element
            while (data[right] > (partitionelement))
                right--;

            // swap the elements
            if (left < right)
                swap(data, left, right);
        }

        // move the partition element into place
        swap(data, min, right);

        return right;
    }

    public String toString(int[] data){
        String result = "";
        for(int i = 0;i<data.length;i++){
            result += data[i] + " ";
        }
        return  result;
    }
}







