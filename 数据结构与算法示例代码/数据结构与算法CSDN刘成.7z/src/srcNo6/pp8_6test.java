package srcNo6;

//*************************************************************************
// pp8_6test.java             Author；Yu KunPeng
//
//*************************************************************************


public class pp8_6test {
    public static void main(String[] args) {
        pp8_6s acc1 = new pp8_6s();

        acc1.addAccount("Ted Murphy", 72354, 102.56);
        acc1.addAccount("Jane Smith", 69713, 40.00);
        acc1.addAccount("Edward Demsery", 93757, 759.32);

        System.out.println(acc1.getbal(0));
        System.out.println();
        System.out.println(acc1.quqian(1, 20, 3));
        System.out.println();
        System.out.println(acc1.xinxi(2));
        System.out.println();
        System.out.println(acc1.cunqian(1, 50));


        acc1.addRate();

        System.out.println(acc1);


    }
}
