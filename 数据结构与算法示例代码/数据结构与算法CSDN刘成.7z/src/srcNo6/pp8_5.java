package srcNo6;
//************************************************************************
// pp8_5.java                Author:Yu Kunpeng
//
//************************************************************************

import java.util.Scanner;

public class pp8_5 {
    public static void main(String[] args) {
        int A, B = 0, C = 0;
        String another = "y";
        int[] num1 = new int[50];
        Scanner scan = new Scanner(System.in);

        while (another.equalsIgnoreCase("y")) {
            System.out.println("请输入数值");
            A = scan.nextInt();
            num1[B] = A;
            B++;
            System.out.println("是否继续输入(y/n)?");
            another = scan.nextLine();
            another = scan.nextLine();

        }

        double average = 0, sum1 = 0, sum2 = 0, sum3;
        for (int num : num1)
            sum1 += num;

        average = sum1 * 1.0 / B;

        for (; C < B; C++) {
            sum2 += ((num1[C] - average) * (num1[C] - average));

        }

        sum3 = Math.pow(sum2, 0.5);

        System.out.println("这组数的平均值为：" + average);
        System.out.println("这组数的标准方差为：" + sum3);
    }
}







