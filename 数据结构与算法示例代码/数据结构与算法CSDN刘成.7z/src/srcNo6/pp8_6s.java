package srcNo6;
//*************************************************************************
// pp8_6test.java             Author；Yu KunPeng
//
//*************************************************************************


public class pp8_6s {
    private double rate = 0.3;
    private int acc;
    Account1[] Acc = new Account1[30];

    public pp8_6s() {
        acc = 0;

    }

    public void addAccount(String A, long B, double C) {
        Account1 zhanghu = new Account1(A, B, C);
        Acc[acc] = zhanghu;
        acc++;
    }

    public void addRate() {
        for (int D = 0; D < acc; D++) {
            Acc[D].addInterest();
        }

    }

    public double getbal(int A) {
        double E = Acc[A].deposit(0);
        return E;
    }

    public double quqian(int F, double H, double J) {
        double G = Acc[F].withdraw(H, J);
        return G;
    }

    public String xinxi(int K) {
        String xinxi = "账户信息" + "\n" + Acc[K];
        return xinxi;

    }

    public double cunqian(int L, double M) {
        double N = Acc[L].deposit(M);
        return N;
    }


    public String toString() {
        String result = "账户信息" + "\n";
        for (int E = 0; E < acc; E++)
            result += Acc[E] + "\n";

        return result;


    }


}
