package srcNo6;
//************************************************************************
// pp8_1.java                Author:Yu Kunpeng
//
//************************************************************************

import java.util.Scanner;

public class pp8_1 {
    public static void main(String[] args) {

        int A;
        int[] num1 = new int[51];
        Scanner scan = new Scanner(System.in);

        while (1 == 1) {
            System.out.println("请输入一个在[0,50]内的数");
            A = scan.nextInt();
            if (A <= 50 && A >= 0)
                num1[A]++;
            else
                break;


        }

        for (int B = 0; B <= 50; B++) {
            System.out.println(B + "出现的次数为" + num1[B]);
        }
    }
}
