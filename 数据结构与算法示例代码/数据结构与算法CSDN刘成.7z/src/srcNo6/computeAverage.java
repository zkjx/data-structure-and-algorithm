//*****************************************************************************
//  computeAverage.java         Author: Yu Kunpeng
//
//*****************************************************************************

public class computeAverage
{
    public static void main(String ... args)
    {
        double A, D = 0.0;
        
        int B = args.length;
        
        for(int C = 1;C < args.length;C++)
        {
            D += Integer.parseInt(args[C]);
        }

        A = D / (args.length - 1);

        System.out.println(args[0] + "'average score is :" + A);
    }
}


