package srcNo17.pp11_3;

public class test {
    public static void main(String[] args) {
        LinkedBinarySearchTree lbs = new LinkedBinarySearchTree();
        lbs.addElement(5);
        lbs.addElement(3);
        lbs.addElement(7);
        lbs.addElement(6);
        lbs.addElement(4);
        lbs.addElement(2);
        lbs.addElement(8);
        System.out.println(lbs);
        System.out.println("最小元素为：" + lbs.findMin());
        System.out.println("最大元素为：" + lbs.findMax());
        lbs.removeMax();
        System.out.println(lbs);

    }
}
