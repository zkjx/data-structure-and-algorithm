package srcNo17.TextbookCode.jsjf;


import srcNo14.TextbookCode.ListADT;
import srcNo14.TextbookCode.OrderedListADT;

import java.util.Iterator;


public class BinarySearchTreeList<T> extends LinkedBinarySearchTree<T>
                      implements ListADT<T>, OrderedListADT<T>, Iterable<T>
{

    public BinarySearchTreeList()
    {
        super();
    }


    public void add(T element)
    {
        addElement(element);
    }


    public T removeFirst()
    {
        return removeMin();
    }


    public T removeLast()
    {
        return removeMax();
    }


    public T remove(T element)
    {
        return removeElement(element);
    }


    public T first()
    {
        return findMin();
    }


    public T last()
    {
        return findMax();
    }


    public Iterator<T> iterator()
    {
        return iteratorInOrder();
    }
}

