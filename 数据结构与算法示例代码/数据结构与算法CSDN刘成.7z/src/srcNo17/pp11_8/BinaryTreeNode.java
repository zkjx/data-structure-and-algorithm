package srcNo17.pp11_8;


import srcNo16.TextbookCode.jsjf.ArrayIterator;

public class BinaryTreeNode<T extends Comparable> {
    public BinaryTreeNode<T> left;
    public BinaryTreeNode<T> right;
    public T element;
    public int height;


    public BinaryTreeNode(T obj) {
        this.element = obj;
        this.left = null;
        this.right = null;
        this.height = 0;
    }


    public BinaryTreeNode(T obj,BinaryTreeNode<T> left, BinaryTreeNode<T> right) {
        this.element = obj;
        this.left= left;
        this.right = right;
        this.height = 0;

    }

    public int ht(BinaryTreeNode<T> subtree) {
        if (subtree == null) {
            return 0;
        } else {
            int l = ht(subtree.left);
            int r = ht(subtree.right);
            return (l > r) ? (l + 1) : (r + 1);
        }
    }


    public BinaryTreeNode<T> singleRotateRight(BinaryTreeNode<T> x) {
        BinaryTreeNode<T> w = x.left;
        x.left = w.right;
        w.right = x;
        x.height = Math.max(ht(x.left), ht(x.right)) + 1;
        w.height = Math.max(ht(w.left), x.height) + 1;
        return w;
    }

    public BinaryTreeNode<T> singleRotateLeft(BinaryTreeNode<T> w) {
        BinaryTreeNode<T> x = w.right;
        w.right = x.left;
        x.left = w;
        w.height = Math.max(ht(w.left), ht(w.right)) + 1;
        x.height = Math.max(ht(x.left), w.height) + 1;
        return x;
    }

    public BinaryTreeNode<T> doubleRotateWithLeft(BinaryTreeNode<T> x) {
        x.left = singleRotateLeft(x.left);
        return singleRotateRight(x);
    }


    public BinaryTreeNode<T> doubleRotateWithRight(BinaryTreeNode<T> x) {
        x.right = singleRotateRight(x.right);
        return singleRotateLeft(x);
    }

    public int numChildren() {
        int children = 0;

        if (left != null)
            children = 1 + left.numChildren();

        if (right != null)
            children = children + 1 + right.numChildren();

        return children;
    }


    public T getElement() {
        return element;
    }


    public BinaryTreeNode<T> getRight() {
        return right;
    }


    public void setRight(BinaryTreeNode<T> node) {
        right = node;
    }


    public BinaryTreeNode<T> getLeft() {
        return left;
    }


    public void setLeft(BinaryTreeNode<T> node) {
        left = node;
    }


    public int count() {
        int result = 1;

        if (left != null)
            result += left.count();

        if (right != null)
            result += right.count();

        return result;
    }


    public void inorder(ArrayIterator<T> iter) {
        if (left != null)
            left.inorder(iter);

        iter.add(element);

        if (right != null)
            right.inorder(iter);
    }


    public void preorder(ArrayIterator<T> iter) {
        iter.add(element);

        if (left != null)
            left.preorder(iter);

        if (right != null)
            right.preorder(iter);
    }


    public void postorder(ArrayIterator<T> iter) {
        if (left != null)
            left.postorder(iter);

        if (right != null)
            right.postorder(iter);

        iter.add(element);
    }

    public boolean isleaf() {
        return this.left == null && this.right == null;
    }


}

