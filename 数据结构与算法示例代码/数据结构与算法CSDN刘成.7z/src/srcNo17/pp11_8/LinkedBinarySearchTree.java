package srcNo17.pp11_8;

import srcNo17.TextbookCode.jsjf.BinarySearchTreeADT;
import srcNo17.TextbookCode.jsjf.exceptions.ElementNotFoundException;
import srcNo17.TextbookCode.jsjf.exceptions.EmptyCollectionException;
import srcNo17.TextbookCode.jsjf.exceptions.NonComparableElementException;

import javax.management.BadBinaryOpValueExpException;

public class LinkedBinarySearchTree<T extends Comparable> extends LinkedBinaryTree<T>
        implements BinarySearchTreeADT<T> {

    public LinkedBinarySearchTree() {
        super();
    }

    public LinkedBinarySearchTree(T element) {
        super(element);

        if (!(element instanceof Comparable))
            throw new NonComparableElementException("LinkedBinarySearchTree");
    }

    private int height(BinaryTreeNode<T> tree) {
        if (tree != null)
            return tree.height;

        return 0;
    }

    public int height() {
        return height(root);
    }


    private BinaryTreeNode<T> singleRotateLeft(BinaryTreeNode<T> x) {
        BinaryTreeNode<T> w = x.left;
        x.left = w.right;
        w.right = x;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        w.height = Math.max(height(w.left), x.height) + 1;
        return w;
    }


    private BinaryTreeNode<T> singleRotateRight(BinaryTreeNode<T> w) {
        BinaryTreeNode<T> x = w.right;
        w.right = x.left;
        x.left = w;
        w.height = Math.max(height(w.left), height(w.right)) + 1;
        x.height = Math.max(height(x.left), w.height) + 1;
        return x;
    }


    private BinaryTreeNode<T> doubleRotateWithLeft(BinaryTreeNode<T> x) {
        x.left = singleRotateRight(x.left);
        return singleRotateLeft(x);
    }


    private BinaryTreeNode<T> doubleRotateWithRight(BinaryTreeNode<T> x) {
        x.right = singleRotateLeft(x.right);
        return singleRotateRight(x);
    }



    public void addElement(T data) {
        if (data == null) {
            throw new RuntimeException("data can\'t not be null ");
        }
        this.root = insert(data, root);
    }

    private BinaryTreeNode<T> insert(T data, BinaryTreeNode<T> p) {
        if (p == null) {
            p = new BinaryTreeNode<T>(data);
        } else if (data.compareTo(p.element) < 0) {
            p.left = insert(data, p.left);
            if (height(p.left) - height(p.right) == 2) {
                if (data.compareTo(p.left.element) < 0) {
                    p = singleRotateLeft(p);
                } else {
                    p = doubleRotateWithLeft(p);
                }
            }
        } else if (data.compareTo(p.element) > 0) {
            p.right = insert(data, p.right);
            if (height(p.right) - height(p.left) == 2) {
                if (data.compareTo(p.right.element) < 0) {
                    p = doubleRotateWithRight(p);
                } else {
                    p = singleRotateRight(p);
                }
            }
        } else ;
        modCount++;
        p.height = Math.max(height(p.left), height(p.right)) + 1;
        return p;
    }


    private BinaryTreeNode<T> replacement(BinaryTreeNode<T> node) {
        BinaryTreeNode<T> result = null;

        if ((node.left == null) && (node.right == null))
            result = null;

        else if ((node.left != null) && (node.right == null))
            result = node.left;

        else if ((node.left == null) && (node.right != null))
            result = node.right;

        else {
            BinaryTreeNode<T> current = node.right;
            BinaryTreeNode<T> parent = node;

            while (current.left != null) {
                parent = current;
                current = current.left;
            }

            current.left = node.left;
            if (node.right != current) {
                parent.left = current.right;
                current.right = node.right;
            }

            result = current;
        }

        return result;
    }


    public void removeAllOccurrences(T targetElement)
            throws ElementNotFoundException {
        removeElement(targetElement);

        try {
            while (contains((T) targetElement))
                removeElement(targetElement);
        } catch (Exception ElementNotFoundException) {
        }
    }


    public T removeMin() throws EmptyCollectionException {
        T result = null;

        if (isEmpty())
            throw new EmptyCollectionException("LinkedBinarySearchTree");
        else {
            if (root.left == null) {
                result = root.element;
                root = root.right;
            } else {
                BinaryTreeNode<T> parent = root;
                BinaryTreeNode<T> current = root.left;
                while (current.left != null) {
                    parent = current;
                    current = current.left;
                }
                result = current.element;
                parent.left = current.right;
            }

            modCount--;
        }

        return result;
    }


    public T removeMax() throws EmptyCollectionException {
        T result = null;

        if (isEmpty())
            throw new EmptyCollectionException("LinkedBinarySearchTree");
        else {
            if (root.right == null) {
                result = root.element;
                root = root.left;
            } else {
                BinaryTreeNode<T> parent = root;
                BinaryTreeNode<T> current = root.right;
                while (current.right != null) {
                    parent = current;
                    current = current.right;
                }
                result = current.element;
                parent.right = current.left;
            }

            modCount--;
        }

        return result;

    }


    public T removeElement(T data) {
        if (data == null) {
            throw new RuntimeException("data can\'t not be null ");
        }
        BinaryTreeNode temp = new BinaryTreeNode(data);
        this.root = remove(root, temp);
        return data;
    }

    private BinaryTreeNode<T> remove(BinaryTreeNode tree, BinaryTreeNode<T> z) {
        if (tree == null || z == null)
            return null;

        int cmp = z.element.compareTo(tree.element);
        if (cmp < 0) {
            tree.left = remove(tree.left, z);
            if (height(tree.right) - height(tree.left) == 2) {
                BinaryTreeNode<T> r = tree.right;
                if (height(r.left) > height(r.right))
                    tree = doubleRotateWithRight(tree);
                else
                    tree = singleRotateRight(tree);
            }
        } else if (cmp > 0) {
            tree.right = remove(tree.right, z);
            if (height(tree.left) - height(tree.right) == 2) {
                BinaryTreeNode<T> l = tree.left;
                if (height(l.right) > height(l.left))
                    tree = doubleRotateWithLeft(tree);
                else
                    tree = singleRotateLeft(tree);
            }
        } else {

            if ((tree.left != null) && (tree.right != null)) {
                if (height(tree.left) > height(tree.right)) {
                    BinaryTreeNode<T> max = findMax(tree.left);
                    tree.element = max.element;
                    tree.left = remove(tree.left, max);
                } else {
                    BinaryTreeNode<T> min = findMin(tree.right);
                    tree.element = min.element;
                    tree.right = remove(tree.right, min);
                }
            } else {
                BinaryTreeNode<T> tmp = tree;
                tree = (tree.left != null) ? tree.left : tree.right;
                tmp = null;
            }
        }

        return tree;

    }


    public T findMin() throws EmptyCollectionException {
        if (isEmpty())
            System.out.println("BinarySearchTree is empty!");

        return findMin(root).getElement();
    }

    private BinaryTreeNode<T> findMin(BinaryTreeNode<T> p) {
        if (p == null)//结束条件
            return null;
        else if (p.left == null)//如果没有左结点,那么t就是最小的
            return p;
        return findMin(p.left);
    }


    public T findMax() throws EmptyCollectionException {
        if (isEmpty())
            System.out.println("BinarySearchTree is empty!");

        return findMax(root).getElement();
    }

    private BinaryTreeNode<T> findMax(BinaryTreeNode<T> p) {

        if (p == null)//结束条件
            return null;
        else if (p.right == null)
            return p;
        return findMax(p.right);
    }


    public T find(T targetElement) throws ElementNotFoundException {
        BinaryTreeNode<T> current = findNode(targetElement, root);

        if (current == null)
            throw new ElementNotFoundException("LinkedBinaryTree");

        return (current.getElement());
    }


    public LinkedBinarySearchTree<T> getLeft() {

        if (root == null)
            throw new srcNo16.TextbookCode.jsjf.exceptions.EmptyCollectionException("Get left operation failed. The tree is empty.");


        LinkedBinarySearchTree<T> result = new LinkedBinarySearchTree<>();
        result.root = root.getLeft();
        return result;
    }


    public LinkedBinarySearchTree<T> getRight() {
        if (root == null)
            throw new srcNo16.TextbookCode.jsjf.exceptions.EmptyCollectionException("Get right operation failed. The tree is empty.");

        LinkedBinarySearchTree<T> result = new LinkedBinarySearchTree<>();
        result.root = root.getRight();
        return result;

    }


    private BinaryTreeNode<T> findNode(T targetElement, BinaryTreeNode<T> next) {

        if (next == null)
            return null;

        if (next.getElement().equals(targetElement))
            return next;

        BinaryTreeNode<T> temp = findNode(targetElement, next.getLeft());

        if (temp == null)
            temp = findNode(targetElement, next.getRight());

        return temp;

    }
}

