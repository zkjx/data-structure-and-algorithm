package srcNo17.pp11_8;

public class test2 {
    public static void main(String[] args) {
        LinkedBinarySearchTree lbs = new LinkedBinarySearchTree();
        lbs.addElement(1);
        lbs.addElement(2);
        lbs.addElement(3);
        lbs.addElement(4);
        lbs.addElement(5);
        lbs.addElement(6);
        System.out.println(lbs);
        lbs.removeElement(3);
        lbs.removeMax();
        lbs.removeMin();
        System.out.println(lbs);
    }
}
