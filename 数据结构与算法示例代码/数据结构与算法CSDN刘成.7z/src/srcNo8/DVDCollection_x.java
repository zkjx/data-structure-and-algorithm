package srcNo8;

//**************************************************************************
//  DVDCollection_x.java          Author:Yu Kunpeng
//
//
//***************************************************************************

import java.text.NumberFormat;

public class DVDCollection_x{
    private DVD_x[] collection;
    private int count;
    private double totalCost;

    public DVDCollection_x() {
        collection = new DVD_x[1];
        count = 0;
        totalCost = 0.0;
    }

    public void addDVD(String title, String director, int year, double cost, boolean bluray) {
        if (count == collection.length)
            increaseSize();

        collection[count] = new DVD_x(title, director, year, cost, bluray);
        totalCost += cost;
        count++;
    }

    public DVD_x[] getCollection(){
        return collection;
    }

    public DVD_x[] sorting(){
        Sorting_x.selectionSort(getCollection());
        return collection;
    }

    public String toString() {
        NumberFormat fmt = NumberFormat.getCurrencyInstance();

        String report = "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
        report += "My DVD Collection\n\n";

        report += "Number of DVDs:" + count + "\n";
        report += "Total cost:" + fmt.format(totalCost) + "\n";
        report += "Average cost:" + fmt.format(totalCost / count);

        report += "\n\nDVD List:\n\n";

        for (int dvd = 0; dvd < count; dvd++)
            report += collection[dvd].toString() + "\n";

        return report;
    }

    private void increaseSize() {
        DVD_x[] temp = new DVD_x[collection.length + 1];

        for (int dvd = 0; dvd < collection.length; dvd++)
            temp[dvd] = collection[dvd];

        collection = temp;

    }
}
