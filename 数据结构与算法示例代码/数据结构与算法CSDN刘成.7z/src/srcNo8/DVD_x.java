package srcNo8;
//*************************************************************************
//  DVD_x.java        Author:Yu Kunpeng
//
//
//*********************************************************************

import java.text.NumberFormat;

public class DVD_x implements Comparable {
    private String title, director;
    private int year;
    private double cost;
    private boolean bluray;

    public DVD_x(String title, String director, int year, double cost, boolean bluray) {
        this.title = title;
        this.director = director;
        this.year = year;
        this.cost = cost;
        this.bluray = bluray;
    }

    public String toString() {
        NumberFormat fmt = NumberFormat.getCurrencyInstance();
        String description;

        description = fmt.format(cost) + "\t" + year + "\t";
        description += title + "\t" + director;
        if (bluray)
            description += "\t" + "Blu-ray";

        return description;

    }

    public String getTitle()
    {
        return title;
    }

    public int compareTo(Object other){
        int result;
        String name = ((DVD_x)other).getTitle();
        result = title.compareTo(name);

        return result;
    }
}
