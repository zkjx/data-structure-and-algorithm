package srcNo12.PP4_2;

import srcNo12.exceptions.EmptyCollectionException;

public class LinkedStack<T> implements StackADT<T> {

    private   int count;
    private LinearNode<T> top;

    public LinkedStack(){
        count = 0;
        top = null;
    }

    @Override
    public void push(T element) {
        LinearNode<T> temp = new LinearNode<T>(element);
        temp.setNext(top);
        top = temp;
        count++;

    }

    @Override
    public T pop() throws EmptyCollectionException {
        if (isEmpty())
            throw new EmptyCollectionException("stack");
        count--;
        T result = top.getElement();
        top =top.getNext();

        return result;
    }

    @Override
    public T peek() throws EmptyCollectionException{
        if (isEmpty())
            throw new EmptyCollectionException("stack");

        T temp = top.getElement();

        return temp;
    }

    @Override
    public boolean isEmpty() {
        if  (size() == 0){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public int size() {
        return count;
    }

    public  String  toString(){
        String result = "";

        LinearNode<T> current = new LinearNode<>();
        current = top;


        int a = count;
        while (a > 0){
            result += current.getElement() + " ";
            current = current.getNext();
            a --;

        }

        return result;
    }
}
