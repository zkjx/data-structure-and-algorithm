package srcNo12.PP4_2;

public class test {
    public static void main(String[] args) {
        LinkedStack Ls = new LinkedStack();
        LinearNode ln1 = new LinearNode(1);
        LinearNode ln2 = new LinearNode("+");
        LinearNode ln3 = new LinearNode(2);
        Ls.push(ln1.getElement());
        Ls.push(ln2.getElement());
        Ls.push(ln3.getElement());
        System.out.println(Ls.size());
        System.out.println(Ls);

        System.out.println( Ls.peek());
        Ls.pop();
        System.out.println(Ls);
    }
}
