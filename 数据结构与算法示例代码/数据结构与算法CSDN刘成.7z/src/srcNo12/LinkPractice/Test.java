package srcNo12.LinkPractice;

public class Test {
    public static void main(String[] args) {
        Number num1 = new Number(3);
        Number num2 = new Number(1);
        Number num3 = new Number(2);
        Number num4 = new Number(5);
        Number num5 = new Number(4);
        LinkList Lt = new LinkList();
        Lt.add(num1);
        Lt.add(num2);
        Lt.add(num3);
        Lt.add(num4);
        Lt.add(num5);
        System.out.println(Lt.toString());
        Lt.delete(num1);;
        System.out.println(Lt.toString());
        Lt.insert(num3,num4);
        System.out.println(Lt.toString());
        Lt.Selection();
        System.out.println(Lt.toString());
    }
}
