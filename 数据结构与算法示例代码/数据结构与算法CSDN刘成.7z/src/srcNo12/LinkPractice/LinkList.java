package srcNo12.LinkPractice;

public class LinkList {
   private NumberNode list;
   private int top = 0;

   public LinkList(){
       list = null;
   }

   public void add(Number num){
       NumberNode node = new NumberNode(num);
       NumberNode current;

       if(list == null)
           list = node;
       else{
           current = list;
           while (current.next != null)
               current = current.next;
           current.next = node;
       }

       top ++;
   }

   public void delete(Number num){
       NumberNode node = new NumberNode(num);
       NumberNode current, temp;

       if(list.Num.number == num.number) {
           current = list.next;
           list = current;
       }
       else{
           current = list;
           while(current.next.Num.number != num.number)
               current = current.next;
           temp = current.next.next;
           current.next = temp;
       }

       top --;
   }

   public void insert(Number num1, Number num2){
       NumberNode node1 = new NumberNode(num1);
       NumberNode node2 = new NumberNode(num2);
       NumberNode current;

       if(list.Num.number == num2.number) {
           current = list;
           node1.next = current;
           list = node1;
       }
       else{
           current = list;
           while(current.next.Num.number != num2.number)
               current = current.next;
           node1.next = current.next;
           current.next = node1;

       }

       top++;
   }

   public void Selection(){
       NumberNode current;
       current = list;
       int[] A = new int[top];
       for(int i = 0; i < top; i++) {
           A[i] = current.Num.number;
           current = current.next;
       }

       Sort sort = new Sort();
       int[] B = sort.selectionSort(A);

       list = null;
       int top2 = top;
       for(int i =0;i< top2; i++){
           Number num = new Number(B[i]);
           add(num);
       }
   }

   public String toString(){
       String result = "";

       NumberNode current = list;

       while (current != null){
           result += current.Num.number + " ";
           current = current.next;

       }

       return result;
   }


   private class NumberNode{
       public Number Num;
       public NumberNode next;

       public NumberNode(Number num){
           Num = num;
           next = null;
       }
   }


}
