package srcNo12.LinkPractice;

import java.util.Scanner;
import java.util.StringTokenizer;

public class LinkTest {
    public static void main(String[] args) {
        int i = 0;
        Number num1 = new Number(3);
        Number num2 = new Number(1);
        LinkList Lt = new LinkList();
        System.out.println("请输入一系列整数");
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        StringTokenizer st = new StringTokenizer(str);
        while (st.hasMoreTokens()){
            Lt.add(new Number(Integer.parseInt(st.nextToken())));
        }
        Lt.add(num1);
        Lt.add(num2);
        Lt.delete(num1);
        System.out.println(Lt.toString());
        Lt.insert(num2,num2);
        System.out.println(Lt.toString());
        Lt.Selection();;
        System.out.println(Lt.toString());
    }
}
