package srcNo12.LinkPractice;

public class Number {
    protected int number;

    protected Number next = null;

    public Number(int number){
        this.number = number;
    }
}
