package srcNo12;
//*******************************************************************
import srcNo12.exceptions.*;
import java.util.Arrays;
import java.util.EmptyStackException;

public class ArrayStack<T> implements StackADT<T> {
    private final int DEFAUKT_CAPACITY = 100;
    
    private int top;
    private T[] stack;
    private String str = "";
    
    public ArrayStack(){
        top = 0;
        stack = (T[])(new Object[DEFAUKT_CAPACITY]);
    }
    
    public ArrayStack(int initialCapacity)
    {
        top = 0;
        stack = (T[])(new Object[initialCapacity]);
    }

    @Override
    public void push(T element) {
        if(size() == stack.length)
            expandCapacity();
        stack[top] = element;
        top++;
    }

    private void expandCapacity() {
        stack = Arrays.copyOf(stack, stack.length * 2);
    }

    @Override
    public T pop() throws EmptyCollectionException{
        if (isEmpty())
            throw new EmptyCollectionException("Stack");
        top--;
        T result = stack[top];
        stack[top] = null;
        
        return result;
    }

    @Override
    public T peek() throws EmptyCollectionException {

        if (isEmpty())
            throw new EmptyCollectionException("Stack");

        return stack[top - 1];
    }

    @Override
    public boolean isEmpty() {
        if  (top == 0){
            System.out.println("此栈为空");
            return true;
        }
        else {
            System.out.println("此栈不为空");
            return false;
        }
    }

    @Override
    public int size() {
        return top;
    }

    public String toString(){
        for (int i = top - 1;i >=  0;i--){
            str += stack[i]+ " ";
        }
        return str;
    }
}
