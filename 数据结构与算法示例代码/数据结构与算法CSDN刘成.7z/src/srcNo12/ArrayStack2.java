package srcNo12;

import srcNo12.exceptions.*;
import java.util.Arrays;
import java.util.EmptyStackException;

public class ArrayStack2<T> implements StackADT<T> {
    private final int DEFAUKT_CAPACITY = 100;

    private int top;
    private T[] stack;
    private String str = "";

    public ArrayStack2(){
        top = 0;
        stack = (T[])(new Object[DEFAUKT_CAPACITY]);
    }

    public ArrayStack2(int initialCapacity)
    {
        top = 0;
        stack = (T[])(new Object[initialCapacity]);
    }

    @Override
    public void push(T element) {
        if(size() == stack.length)
            expandCapacity();
        stack[top] = element;
        top++;
    }

    private void expandCapacity() {
        stack = Arrays.copyOf(stack, stack.length * 2);
    }

    @Override
    public T pop() throws EmptyCollectionException{
        if (isEmpty())
            throw new EmptyCollectionException("Stack");
        top--;
        T result = stack[top];
        stack[top] = null;

        return result;
    }

    @Override
    public T peek() throws EmptyCollectionException {

        if (isEmpty())
            throw new EmptyCollectionException("Stack");

        return stack[top - 1];
    }

    @Override
    public boolean isEmpty() {
        if  (top == 0){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public int size() {
        return top;
    }

    public String toString(){
        String result = "";
        for (int i = 0;i <top;i++){
            result += stack[i]+ " ";
        }


        return result;
    }
}

