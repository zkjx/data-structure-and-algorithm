package srcNo12;

import java.util.Scanner;
import java.util.StringTokenizer;

public class reverseTest {
    public static void main(String[] args){
        System.out.println("please enter: ");
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        reverse re = new reverse(str);
    }
}
