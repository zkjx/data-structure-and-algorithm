package srcNo12;
//********************************************************
public class test {
    public static void main (String[] args){
        ArrayStack stack = new ArrayStack(2);
        stack.push(10);
        stack.push(20);
        stack.push(30);
        System.out.println("此时栈的长度为：" + stack.size());
        System.out.println("此时栈顶的数字为：" + stack.peek());
        System.out.println(stack);
        System.out.println(stack.pop());
        System.out.println("此时栈的长度为：" + stack.size());
        stack.isEmpty();



    }
}
