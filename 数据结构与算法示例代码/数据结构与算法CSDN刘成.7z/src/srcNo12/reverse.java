package srcNo12;

import srcNo12.exceptions.*;
import java.util.Arrays;
import java.util.EmptyStackException;
import java.util.Scanner;
import java.util.StringTokenizer;
//***********************************************************
public class reverse{

    public reverse(String str){
        ArrayStack2 stack = new ArrayStack2();

        int a = str.length();

        for(int i = 0; i < a; i++)
            stack.push(str.charAt(i));

        for(int i = 0;i < a;i++) {
            System.out.print(stack.pop() + "");
        }

    }

}
