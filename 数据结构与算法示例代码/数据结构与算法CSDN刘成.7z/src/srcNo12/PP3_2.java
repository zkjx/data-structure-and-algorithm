package srcNo12;

import java.util.Scanner;
import java.util.Stack;
import java.util.StringTokenizer;


public class PP3_2 {
    public static void main(String[] args){
        ArrayStack2 stack = new ArrayStack2();
        Scanner scan = new Scanner(System.in);
        System.out.println("请输入一个句子");
        String str = scan.nextLine();
        StringTokenizer st = new StringTokenizer(str);
        while(st.hasMoreTokens())
        {
            String temp = st.nextToken();
            int a = temp.length();
            for(int i = 0; i < a; i++)
                stack.push(temp.charAt(i));

            for(int i = 0;i < a;i++) {
                System.out.print(stack.pop() + "");
            }
            System.out.print(" ");

        }

    }
}