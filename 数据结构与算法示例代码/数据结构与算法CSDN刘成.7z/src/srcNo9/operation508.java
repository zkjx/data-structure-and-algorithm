package srcNo9;
//***************************************************************************
// operation508.java         Author:Yu Kunpeng
//
//***************************************************************************
import java.util.*;
import java.io.* ;

public class operation508 {
    String B;
    public int[] c;
    public StringTokenizer st;

    public operation508() {
        Scanner scan = new Scanner(System.in);
        System.out.println("请输入任意个整数");
        String A = scan.nextLine();
        st = new StringTokenizer(A);


        try {
            OutputStream outputStream3 = new FileOutputStream(new File("G://Sort//sort.txt"));
            outputStream3.write("".getBytes());
            outputStream3.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
            OutputStream outputStream = new FileOutputStream("G://Sort//sort.txt", true);
            outputStream.write(A.getBytes());
            outputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void input() {
        int i = 0;
        int h = 0;
        try {
            InputStream inputStream = new FileInputStream(new File("G://Sort//sort.txt"));
            while (inputStream.available() > 0) {
                 B += inputStream.read()+"";
            }

                c = new int[st.countTokens()];
               System.out.println("从文件中读出的整数为");
                while (st.hasMoreTokens()) {
                    String str = st.nextToken();
                    System.out.print(str + " ");
                    c[h] = Integer.parseInt(str);
                    h ++;
                }
            inputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println();
        System.out.println("排序后，这些整数排列如下");
        insertinSort(c);
       for (int v = 0; v < c.length; v++)
           System.out.print(c[v]+ " ");


    }


    public int[] insertinSort(int[] list){
            for (int index = 1; index < list.length; index++) {
                int key = list[index];
                int position = index;

                while (position > 0 && key - (list[position - 1]) < 0) {
                    list[position] = list[position - 1];
                    position--;
                }

                list[position] = key;
            }
            return list;
        }
        
        public void write(int[] list) {
            try {
                String temp;
                OutputStream outputStream2 = new FileOutputStream("G://Sort//sort.txt", true);
                outputStream2.write("\r\n".getBytes());
                for (int z = 0; z < list.length; z++){
                    temp = list[z] + "";
                    outputStream2.write(temp.getBytes());

                }
            } catch (FileNotFoundException e1) {
                e1.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
}
