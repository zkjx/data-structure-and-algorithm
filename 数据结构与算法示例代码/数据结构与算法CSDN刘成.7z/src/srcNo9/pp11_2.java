package srcNo9;
/*
        Author: Yu Kunpeng              pp11_1.java
 */

import java.util.Scanner;

public class pp11_2 {
    public static void main(String[] args){
        final int NUM = 20;

        Scanner scan = new Scanner(System.in);

        StringTooLongException problem = new StringTooLongException("The input string is too long.");

        System.out.println("Please enter the appropriate length of the string: " + NUM);
        String string = scan.nextLine();

        try {
            if (string.length() > NUM);
            throw problem;
        }
        catch (StringTooLongException exception)
        {
            System.out.println("The input string is too long.");
        }


        if(string.substring (string.length() - 4, string.length()).equals("DONE" ))
            System.out.println("End.");


    }
}
