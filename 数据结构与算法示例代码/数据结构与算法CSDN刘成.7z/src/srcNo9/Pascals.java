package srcNo9;

import java.util.Scanner;

public class Pascals {


    public static int digui(int i, int j) {
        if (j == 0 || j == i)
            return 1;
        else
            return digui(i - 1, j) + digui(i - 1, j - 1);

    }

    public static void main(String args[]) {
        System.out.println("请输入Pascal三角形的行数");
        Scanner scan = new Scanner(System.in);
        int A = scan.nextInt();

        int pas[][];
        pas = new int[A][A];
        for (int i = 0; i < A; i++)
            for (int j = 0; j <= i; j++)
                pas[i][j] = digui(i, j);

        for (int i = 0; i < A; i++) {
            System.out.println();
            for (int n = A - i; n >= 1; n--)
                System.out.print(" ");
            for (int j = 0; j <= i; j++)
                System.out.print(pas[i][j] + " ");
        }

    }
}
