package srcNo9;
//******************************************************************************************
// Tset.java                        Author:Yu Kunpeng
//
//******************************************************************************************

public class Test {
    public static void main(String[] args) {
        operation508 A = new operation508();
        A.input();





    }
}
