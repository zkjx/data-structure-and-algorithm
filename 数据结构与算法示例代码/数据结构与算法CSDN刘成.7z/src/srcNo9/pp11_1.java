package srcNo9;
/*
        Author: Yu Kunpeng              pp11_1.java
 */

import java.util.Scanner;

public class pp11_1 {
    public static void main(String[] args) throws StringTooLongException {
        final int NUM = 20;

        Scanner scan = new Scanner(System.in);

        StringTooLongException problem = new StringTooLongException("The input string is too long.");

        System.out.println("Please enter the appropriate length of the string: " + NUM);
        String string = scan.nextLine();
        if (string.length() > NUM)
            throw problem;

        if(string.substring (string.length() - 4, string.length()).equals("DONE" ))
            System.out.println("End.");


    }
}
