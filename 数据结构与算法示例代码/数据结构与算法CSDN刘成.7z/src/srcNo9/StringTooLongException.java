package srcNo9;
/*
     Author: Yu Kunpeng                StringTooLongException.java
*/

public class StringTooLongException extends Exception {
    StringTooLongException(String message){
        super(message);
    }
}
