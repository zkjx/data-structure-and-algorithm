package srcNo9;
import java.util.Scanner;

public class expractice509test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("请输入一个数");
        int A = scan.nextInt();
        expractice509 exp = new expractice509();
        int result = exp.Cal(A);
        exp.write(result);
        System.out.println("F(n)的结果为" + result);

    }


}
