package srcNo9;
import java.io.*;

public class expractice509 {

    public int Cal(int num){
        int A;
        if (num == 0)
            return A = 0;
        else{
            if (num == 1)
                return A = 1;
            else {
                A = Cal(num - 1) + Cal(num - 2);
                return A;
            }
        }

    }

    public void write(int num){
        try{
            OutputStream outputStream3 = new FileOutputStream(new File("G://Sort//sort.txt"));
            outputStream3.write("".getBytes());
            outputStream3.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            String B = num + "";
            OutputStream outputStream = new FileOutputStream("G://Sort//sort.txt",true);
            outputStream.write(B.getBytes());
            outputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
