package srcNo9;
/*
        Author: Yu Kunpeng              pp12_1.java
 */

import java.util.*;

public class pp12_1 {
    public int left, right;
    public String str;

    public pp12_1(){
        System.out.println("Enter a potential palidrome.");
        Scanner scan = new Scanner(System.in);
        str = scan.nextLine();
        left = 0;
        right = str.length() - 1;
    }

    public void huiwen(){
        while (str.charAt(left) == str.charAt(right) && left < right)
        {
            left ++;
            right --;
            huiwen();

        }
    }

    public void torf(){
        if (left < right)
        System.out.println("That string is NOT a palindrome.");
        else
        System.out.println("That string is a palindrome.");
    }

    //---------------------------------------------------------------------------------------------------
    public static void main(String[] args) {
        pp12_1 A = new pp12_1();
        A.huiwen();
        A.torf();

    }
}
