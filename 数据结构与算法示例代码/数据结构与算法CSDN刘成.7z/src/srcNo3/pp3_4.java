import java.util.Scanner;

public class pp3_4
{
    public static void main(String[] args)
    {
        double num1, num2, num3;
        
        Scanner  scan = new Scanner(System.in);
        
        System.out.println("please shuru num1: ");
        num1 = scan.nextDouble();

        num2 = Math.floor(num1);
        num3 = Math.floor(num1) + 1;
        
        System.out.println(num2 + "," + num3);
    }
}
