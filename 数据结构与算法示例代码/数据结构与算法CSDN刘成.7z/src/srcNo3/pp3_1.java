//-----------------------------------------------------------
// pp3_1.java   Author: 余坤澎
//-----------------------------------------------------------

import java.util.Random;
import java.util.Scanner;

public class pp3_1
{
    public static void main(String[] args)
    {
        int num1;
        char a;
           
        Random generator = new Random();

        String name, xing, xing1;
        Scanner scan = new Scanner(System.in);

        System.out.println("请输入你的名字: ");
        name = scan.nextLine();

        System.out.println("请输入你的姓氏: ");
        xing = scan.nextLine();

        num1 = generator.nextInt(91) + 10;

        xing1 = xing.substring(0, 5);
        a = name.charAt(0);

        System.out.println( a + xing1 + num1);
    }
}



