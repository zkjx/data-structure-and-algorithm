//**********************************************************
// pp3_8     Author:余坤澎
//**********************************************************

import java.util.Random;

public class pp3_8
{
    public static void main(String[] args)
    {
        Random generator = new Random();
        
        int a;
        double b, c, d;

        a = generator.nextInt(21);
        System.out.println("产生的随机整形数: " + (a+20));

        b = Math.cos(a+20);
        System.out.println("该随机整形数的余弦值: " + b);
        c = Math.sin(a+20);
        System.out.println("该随机整形数的正弦值: " + c);
        d = Math.tan(a+20);
        System.out.println("该随机整形数的正切值: " + d);
    }
}
