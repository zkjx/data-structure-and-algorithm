import java.util.Scanner;

public class pp3_2
{
    public static void main(String[] args)
    {
        int num1, num2;
        double num3, num4;

        Scanner scan = new Scanner(System.in);

        System.out.println("Please shuru num1: ");
        num1 = scan.nextInt();

        System.out.println("Please shuru num2: ");
        num2 = scan.nextInt();

        num3 = Math.pow(num1, 3);
        num4 = Math.pow(num2, 3);

        System.out.println(num3 + num4);
    }
}

