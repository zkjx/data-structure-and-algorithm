//***************************************************************
//  pp3_3.java         Author : 余坤澎
//***************************************************************

import java.util.Random;

public class pp3_3
{
    public static void main(String[] args)
    {
        Random generator = new Random();
        int num1, num2, num3, num4, num5, num6, num7, num8, num9, num10;
 
        num1 = generator.nextInt(8);
        num2 = generator.nextInt(8); 
        num3 = generator.nextInt(8); 
        num4 = generator.nextInt(7);
        
        if (num4 < 6)
        {
            num5 = generator.nextInt(10);
            num6 = generator.nextInt(10);
        }
        else
             num5 = generator.nextInt(6);
            if (num5 < 5)
                num6 = generator.nextInt(10);
            else
                num6 = generator.nextInt(6);
                
        num7 = generator.nextInt(10);
        num8 = generator.nextInt(10);
        num9 = generator.nextInt(10);
        num10 = generator.nextInt(10);

        System.out.println("得到的随机号码为: " +num1+num2+num3+"-"+
        num4+num5+num6+"-"+num7 +num8+num9+num10);
    }
}
                  


            
          
    




