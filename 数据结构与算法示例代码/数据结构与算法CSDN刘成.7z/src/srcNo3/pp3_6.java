import java.util.Scanner;
import java.text.DecimalFormat;

public class pp3_6
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);

        double num1, num2, num3, num4, num5;
        String num6, num7;

        System.out.println("Please shuru banjing: ");
        num1 = scan.nextDouble();

        num2 = 4/3;

        num3 = num2 * Math.PI;
        num4 = Math.pow(num3, 3);
        num5 = Math.pow(4 * Math.PI, 2);

        DecimalFormat num = new DecimalFormat("0.####");

        num6=num.format(num4);
        num7=num.format(num5);

        System.out.println("体积: " + num6 + "," + "面积: " + num7);
    }
}





    
