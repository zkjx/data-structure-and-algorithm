//***********************************************************
// pp3_5.java  Author:余坤澎
//***********************************************************

import java.util.Scanner;

public class pp3_5
{
    public static void main(String[] args)
    {
        double a, b, c, d, e, f, g;

        Scanner scan = new Scanner(System.in);

        System.out.print("请输入一个点的横坐标: ");
        a = scan.nextInt();
        System.out.print("请输入该点的纵坐标: ");
        b = scan.nextInt();

        System.out.print("请输入另一个点的横坐标: ");
        c = scan.nextInt();
        System.out.print("请输入该点的纵坐标: ");
        d = scan.nextInt();

        e = Math.pow((a - c), 2);
        f = Math.pow((b - d), 2);

        g = Math.pow((e + f), 0.5);

        System.out.println("两点间的距离为: " + g + "\n");
    }
}


