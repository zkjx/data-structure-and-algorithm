package srcNo18.pp12_1;

public class test {
    public static void main(String[] args) {
        HeapQueue hq = new HeapQueue();
        hq.enqueue(3);
        hq.enqueue(5);
        hq.enqueue(2);
        hq.enqueue(1);
        hq.enqueue(4);
        System.out.println(hq);
    }
}
