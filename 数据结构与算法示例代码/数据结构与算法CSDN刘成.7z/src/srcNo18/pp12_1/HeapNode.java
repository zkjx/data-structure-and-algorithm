package srcNo18.pp12_1;

import srcNo18.SecondPractice.BinaryTreeNode;


public class HeapNode<T> extends BinaryTreeNode<T> implements Comparable<HeapNode<T>>
{
    public HeapNode<T> parent;
    public int com;


    public HeapNode(T obj) 
    {
        super(obj);
        parent = null;
    }

    public void setCom(int com){
        this.com = com;
    }

    public HeapNode<T> getParent()
    {
        return parent;
    }
	

    public void setElement(T obj) 
    {
        element = obj;
    }
	

    public void setParent(HeapNode<T> node)
    {
        parent = node;
    }

    @Override
    public int compareTo(HeapNode<T> hn) {
        if (com>hn.com)
            return 1;
        else
            return -1;
    }
}


