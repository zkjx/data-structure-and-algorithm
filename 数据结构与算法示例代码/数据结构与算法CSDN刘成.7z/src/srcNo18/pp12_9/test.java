package srcNo18.pp12_9;

public class test {
    public static void main(String[] args) {
        LinkedHeap ah = new LinkedHeap();
        ah.addElement(5);
        ah.addElement(1);
        ah.addElement(3);
        ah.addElement(4);
        System.out.println(ah);
        System.out.println(ah.findMin());
        System.out.println(ah.removeMin());
        System.out.println(ah);


    }
}
