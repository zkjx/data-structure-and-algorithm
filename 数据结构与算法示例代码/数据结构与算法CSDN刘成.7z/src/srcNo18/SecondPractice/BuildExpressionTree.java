package srcNo18.SecondPractice;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class BuildExpressionTree {
    BinaryTreeNode node;

    public BinaryTreeNode buildTree(String str) {
        ArrayList<String> operList = new ArrayList<>();
        ArrayList<LinkedBinaryTree> numList = new ArrayList<>();
        StringTokenizer st = new StringTokenizer(str);
        String token;
        while (st.hasMoreTokens()) {
            token = st.nextToken();
            if (token.equals("(")) {
                String str1 = "";
                while (true) {
                    token = st.nextToken();
                    if (!token.equals(")"))
                        str1 += token + " ";
                    else
                        break;
                }
                LinkedBinaryTree temp = new LinkedBinaryTree();
                temp.root = buildTree(str1);
                numList.add(temp);
                token = st.nextToken();
            }
            if (token.equals("+") || token.equals("-")) {
                operList.add(token);
            } else if (token.equals("*") || token.equals("/")) {
                LinkedBinaryTree left = numList.remove(numList.size() - 1);
                String A = token;
                token = st.nextToken();
                if (!token.equals("(")) {
                    LinkedBinaryTree right = new LinkedBinaryTree(token);
                    LinkedBinaryTree node = new LinkedBinaryTree(A, left, right);
                    numList.add(node);
                } else {
                    String str1 = "";
                    while (true) {
                        token = st.nextToken();
                        if (!token.equals(")"))
                            str1 += token + " ";
                        else
                            break;
                    }
                    LinkedBinaryTree temp2 = new LinkedBinaryTree();
                    temp2.root = buildTree(str1);
                    LinkedBinaryTree node1 = new LinkedBinaryTree(A, left, temp2);
                    numList.add(node1);
                }
            } else
                numList.add(new LinkedBinaryTree(token));
        }
        while (operList.size() > 0) {
            LinkedBinaryTree left = numList.remove(0);
            LinkedBinaryTree right = numList.remove(0);
            String oper = operList.remove(0);

            LinkedBinaryTree node2 = new LinkedBinaryTree(oper, left, right);
            numList.add(0, node2);
        }
        node = (numList.get(0)).root;

        return node;
    }


}
