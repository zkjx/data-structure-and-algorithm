package srcNo18.SecondPractice;


import java.io.FileNotFoundException;

public class test3 {
    public static void main (String[] args) throws FileNotFoundException
    {
        System.out.println ("So, your computer is broken");

        DecisionTree expert = new DecisionTree("input2.txt");
        expert.evaluate();
        System.out.println(expert.tree);
    }
}
