package srcNo18.SecondPractice;
import java.util.Iterator;

public class test1 {
    public static void main(String[] args) {
        BinaryTreeNode bt1 = new BinaryTreeNode(1);
        BinaryTreeNode bt2 = new BinaryTreeNode(2);
        BinaryTreeNode bt3 = new BinaryTreeNode(3);
        BinaryTreeNode bt4 = new BinaryTreeNode(4);
        BinaryTreeNode bt5 = new BinaryTreeNode(5);

        LinkedBinaryTree lbt1 = new LinkedBinaryTree(bt4.getElement());
        LinkedBinaryTree lbt2 = new LinkedBinaryTree(bt5.getElement());
        LinkedBinaryTree lbt3 = new LinkedBinaryTree(bt3.getElement());
        LinkedBinaryTree lbt4 = new LinkedBinaryTree(bt2.getElement(),lbt1,lbt2);
        LinkedBinaryTree lbt5 = new LinkedBinaryTree(bt1.getElement(),lbt4,lbt3);

        System.out.println(lbt5);
        System.out.println(lbt5.getRight());
        System.out.println(lbt5.getLeft());
        Iterator it1 = lbt5.iteratorPostOrder();
        Iterator it2 = lbt5.iteratorPreOrder();
        System.out.println("后序遍历");
        while(it1.hasNext())
            System.out.print(it1.next()+" ");
        System.out.println();
        System.out.println("前序遍历");
        while(it2.hasNext())
            System.out.print(it2.next()+" ");
        lbt5.removeRightSubtree(2);            //删除element为2的右子树
        System.out.println();
        System.out.println(lbt5.contains(5));

    }
}
