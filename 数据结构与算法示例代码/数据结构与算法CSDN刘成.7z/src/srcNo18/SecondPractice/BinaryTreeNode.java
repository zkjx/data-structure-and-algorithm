package srcNo18.SecondPractice;

public class BinaryTreeNode<T>
{
    public T element;
    public BinaryTreeNode<T> left, right;


    public BinaryTreeNode(T obj) 
    {
        element = obj;
        left = null;
        right = null;
    }


    public BinaryTreeNode(T obj, LinkedBinaryTree<T> left, LinkedBinaryTree<T> right)
    {
        element = obj;
        if (left == null)
            this.left = null;
        else
            this.left = left.getRootNode();
        
         if (right == null)
            this.right = null;
        else
            this.right = right.getRootNode();
    }
    

    public int numChildren() 
    {
        int children = 0;

        if (left != null)
            children = 1 + left.numChildren();

        if (right != null)
            children = children + 1 + right.numChildren();

        return children;
    }
    

    public T getElement() 
    {
        return element;
    }
    

    public BinaryTreeNode<T> getRight()
    {
        return right;
    }
    

    public void setRight(BinaryTreeNode<T> node)
    {
        right = node;
    }
    

    public BinaryTreeNode<T> getLeft()
    {
        return left;
    }
    

    public void setLeft(BinaryTreeNode<T> node)
    {
        left = node;
    }


    public int count(){
        int result = 1;

        if(left != null)
            result += left.count();

        if(right != null)
            result += right.count();

        return result;
    }




    public void inorder(ArrayIterator<T> iter){
        if(left != null)
            left.inorder(iter);

        iter.add(element);

        if(right != null)
            right.inorder(iter);
    }


    public void preorder(ArrayIterator<T> iter){
        iter.add(element);

        if(left != null)
            left.preorder(iter);

        if(right != null)
            right.preorder(iter);
    }


    public void postorder(ArrayIterator<T> iter){
        if(left != null)
            left.postorder(iter);

        if(right != null)
            right.postorder(iter);

        iter.add(element);
    }

    public boolean isleaf(){
        return this.left==null&&this.right==null;
    }
}

