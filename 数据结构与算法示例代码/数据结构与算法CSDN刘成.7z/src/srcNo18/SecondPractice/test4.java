package srcNo18.SecondPractice;

import srcNo16.TextbookCode.PostfixEvaluator;

import java.util.Iterator;
import java.util.Scanner;

public class test4 {
    public static void main(String[] args) {
        String expression, again, temp = "";
        int result;

        Scanner in = new Scanner(System.in);

        LinkedBinaryTree lbt = new LinkedBinaryTree();
        BuildExpressionTree bt = new BuildExpressionTree();

        do
        {
            PostfixEvaluator evaluator = new PostfixEvaluator();
            System.out.println("Enter a valid post-fix expression one token " +
                    "at a time with a space between each token (e.g. 5 - 3 * ( 4 + 9 ))");
            expression = in.nextLine();
            lbt.root = bt.buildTree(expression);
            Iterator it = lbt.iteratorPostOrder();
            while(it.hasNext())
                temp += it.next() + " ";

            System.out.println();
            System.out.println("The postfixexpression is " + temp);
            result = evaluator.evaluate(temp);
            System.out.println("That expression equals " + result);

            System.out.println("The Expression Tree for that expression is: ");
            System.out.println(evaluator.getTree());

            System.out.print("Evaluate another expression [Y/N]? ");
            again = in.nextLine();
            System.out.println();
        }
        while (again.equalsIgnoreCase("y"));

    }
}
