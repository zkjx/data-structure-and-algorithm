package srcNo18.classpractice119;

public class test {
    public static void main(String[] args) {
        ArrayHeap ah = new ArrayHeap();
        //36,30,18,40,32,45,22,50
        ah.addElement(36);
        ah.addElement(30);
        ah.addElement(18);
        ah.addElement(40);
        ah.addElement(32);
        ah.addElement(45);
        ah.addElement(22);
        ah.addElement(50);
        System.out.println(ah);
        System.out.println(ah.removeMax());
        ah.sort();




    }
}
