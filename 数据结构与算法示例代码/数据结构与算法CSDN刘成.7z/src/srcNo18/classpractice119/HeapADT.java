package srcNo18.classpractice119;

import srcNo18.SecondPractice.BinaryTreeADT;


public interface HeapADT<T> extends BinaryTreeADT<T>
{
   /** 
    * Adds the specified object to this heap. 
    *
    * @param obj the element to be added to the heap
    */   
   public void addElement(T obj);
   
   /** 
    * Removes element with the lowest value from this heap. 
    *
    * @return the element with the lowest value from the heap
    */
   public T removeMax();
   
   /** 
    * Returns a reference to the element with the lowest value in 
    * this heap. 
    *
    * @return a reference to the element with the lowest value in the heap
    */
   public T findMax();
}


