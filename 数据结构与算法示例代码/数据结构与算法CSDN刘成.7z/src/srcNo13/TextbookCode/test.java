package srcNo13.TextbookCode;

public class test {
    public static void main(String[] args) {
        LinkedQueue que = new LinkedQueue();
        que.enqueue(1);
//        que.enqueue(2);
        System.out.println(que);
    }
}
