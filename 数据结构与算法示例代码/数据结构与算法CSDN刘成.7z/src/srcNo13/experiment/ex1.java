package srcNo13.experiment;

import java.util.Scanner;
import java.util.StringTokenizer;

public class ex1 {
    public static void main(String[] args) {
        LinkedQueue lq = new LinkedQueue();
        System.out.println("请输入一系列整数：");
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        StringTokenizer st = new StringTokenizer(str);
        while(st.hasMoreTokens()){
            lq.enqueue(st.nextToken());
        }
        System.out.println("链表内的元素为" + lq);
        System.out.println("链表内元素的个数为" + lq.size());



    }
}
