package srcNo13.experiment;

import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ex4 {
    public static void main(String[] args) {
        int i = 0;
        char[] A = new char[10];
        File fromFile = new File("G://Sort//sort.txt");
        Reader reader = null;
        try {
            reader = new FileReader(fromFile);
            int content = reader.read();
            while (content != -1) {
                A[i] = (char) content;
                i ++;
                content = reader.read();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Array ay = new Array();
        System.out.println("请输入一系列整数：");
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        StringTokenizer st = new StringTokenizer(str);
        while(st.hasMoreTokens()){
            ay.add(st.nextToken());
        }
        System.out.println("链表内的元素为" + ay);
        System.out.println("链表内元素的个数为" + ay.size());

        ay.add(Integer.parseInt(A[0]+""),5);
        System.out.println("链表内的元素为" + ay);
        System.out.println("链表内元素的个数为" + ay.size());
        ay.add(Integer.parseInt(A[1]+""),0);
        System.out.println("链表内的元素为" + ay);
        System.out.println("链表内元素的个数为" + ay.size());
        ay.delete(6);
        System.out.println("链表内的元素为" + ay);
        System.out.println("链表内元素的个数为" + ay.size());
    }
}
