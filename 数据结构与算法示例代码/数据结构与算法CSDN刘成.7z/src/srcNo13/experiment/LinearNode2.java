package srcNo13.experiment;

public class LinearNode2<T> {
    private LinearNode2<T> next, previous;
    private T element;

    public LinearNode2(){
        next = null;
        element = null;
        previous = null;
    }

    public LinearNode2(T elem){
        next = null;
        element = elem;
    }

    public LinearNode2<T> getNext(){
        return next;
    }

    public void setNext(LinearNode2<T> node){
        next = node;
    }

    public LinearNode2<T> getPrevious(){
        return previous;
    }

    public void setPrevious(LinearNode2<T> node){
        previous = node;
    }

    public T getElement(){
        return element ;
    }

    public void setElement(T elem){
        element = elem;
    }
}
