package srcNo13.experiment;

import srcNo12.PP4_2.LinearNode;
import srcNo13.exceptions.EmptyCollectionException;

public class LinkedQueue2<T> implements QueueADT<T>{
    private int nYuKunpeng;
    private LinearNode2<T> head, tail;

    public LinkedQueue2(){
        nYuKunpeng = 0;
        head = tail = null;
    }



    @Override
    public void enqueue(T element) {
        LinearNode2<T> node = new LinearNode2<T>(element);

        if(isEmpty())
            head = node;
        else {
            tail.setNext(node);
            node.setPrevious(tail);
        }
        tail = node;
        nYuKunpeng ++;
    }

    @Override
    public T dequeue() throws EmptyCollectionException {

        if(isEmpty())
            throw new EmptyCollectionException("queue");

        T result = head.getElement();
        head = head.getNext();
        nYuKunpeng --;

        if(isEmpty())
            tail = null;

        return result;
    }

    public void insert(T element1, int A){
        LinearNode2<T> node1 = new LinearNode2<T>(element1);
        LinearNode2<T> current = head;

        if(A==0){
            node1.setNext(current);
            current.setPrevious(node1);
            head = node1;
        }
        else{
            for(int i = 1; i < A; i ++) {
                current = current.getNext();

            }
            node1.setNext(current.getNext());
            current.getNext().setPrevious(node1);
            current.setNext(node1);
            node1.setPrevious(current);
        }

        nYuKunpeng++;



    }

    public void delete(int A){
        LinearNode2 current, temp = null;
        current = head;

        if( A == 0)
            head = head.getNext();
        else{
            if(A == nYuKunpeng - 1)
                tail = tail.getPrevious();
            else{
                for(int i = 0; i < A; i ++) {
                    temp = current;
                    current = current.getNext();
                }
                temp.setNext(current.getNext());
                current.getNext().setPrevious(temp);
            }



        }

        nYuKunpeng --;
    }




    public void sort(){
        LinearNode2<T> current, temp = null, current2 = head;
        int m = nYuKunpeng;
        T n;
        for(current = head; current != null; current = current.getNext()){
            for(temp = current;temp.getPrevious() != null; temp = temp.getPrevious()){
                if(Integer.parseInt(temp.getPrevious().getElement()+"")>Integer.parseInt(temp.getElement()+ "")){
                    n = temp.getPrevious().getElement();
                    temp.getPrevious().setElement(temp.getElement());
                    temp.setElement(n);
                }
            }
            System.out.println("此轮排序后元素的顺序" + toString() + "此时元素的个数为" + size());
        }



    }

    @Override
    public T first() {
        return head.getElement();
    }

    @Override
    public boolean isEmpty() {
        if (nYuKunpeng == 0)
            return true;
        else
            return false;
    }

    @Override
    public int size() {
        return nYuKunpeng;
    }

    public String toString(){
        String result = "";
        LinearNode2<T> current = head;
        int a = nYuKunpeng;
        while(a > 0) {
            result += current.getElement()+ ",";
            current = current.getNext();
            a--;
        }

        return result;
    }

}
