package srcNo13.experiment;

import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ex3 {
    public static void main(String[] args) {

        LinkedQueue2 lq1 = new LinkedQueue2();
        File fromFile = new File("G://Sort//sort.txt");
        Reader reader = null;
        try {
            reader = new FileReader(fromFile);
            int content = reader.read();
            while (content != -1) {
                lq1.enqueue((char)content);
                content = reader.read();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                reader.close();
            } catch (IOException e)
            {
                e.printStackTrace();
            }
        }


        LinkedQueue2 lq2 = new LinkedQueue2();
        System.out.println("请输入一系列整数：");
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        StringTokenizer st = new StringTokenizer(str);
        while(st.hasMoreTokens()){
            lq2.enqueue(st.nextToken());
        }


        lq2.insert(lq1.dequeue(),5);
        System.out.println("链表内的元素为" + lq2);
        System.out.println("链表内元素的个数为" + lq2.size());
        lq2.insert(lq1.dequeue(),0);
        System.out.println("链表内的元素为" + lq2);
        System.out.println("链表内元素的个数为" + lq2.size());
        lq2.delete(6);
        System.out.println("链表内的元素为" + lq2);
        System.out.println("链表内元素的个数为" + lq2.size());

        lq2.sort();

    }
}
