package srcNo13.experiment;

import srcNo13.exceptions.EmptyCollectionException;

import java.util.Arrays;

public class Array<T> implements ArrayADT<T> {
    private final int DEFAUKT_CAPACITY = 100;

    private int nYuKunpeng;
    private T[] A;

    public Array(){
        nYuKunpeng = 0;
        A = (T[])(new Object[DEFAUKT_CAPACITY]);
    }

    public Array(int initialCapacity){
        nYuKunpeng = 0;
        A = (T[])(new Object[initialCapacity]);
    }

    public void add(T element) {
        if(size() == A.length)
            expandCapacity();
        A[nYuKunpeng] = element;
        nYuKunpeng++;
    }

    private void expandCapacity() {
        A = Arrays.copyOf(A, A.length * 2);
    }


    public void add(T element, int a){
        T[] B = (T[])(new Object[size() + 1]);
        for(int i =0; i < a;i ++)
            B[i] = A[i];
        B[a] = element;
        for(int i = a + 1;i < size() + 1; i ++ ) {
            B[i] = A[i - 1];
        }
        A = B;
        nYuKunpeng ++;
    }


    @Override
    public T delete() {
        if (isEmpty())
            throw new EmptyCollectionException("Stack");
        nYuKunpeng--;
        T result = A[nYuKunpeng];
        A[nYuKunpeng] = null;

        return result;
    }

    public void delete(int a){
        T[] B = (T[])(new Object[size() - 1 ]);
        for(int i = 0;i < a; i++)
            B[i] = A[i];
        for(int i = a;i < size() - 1; i++)
            B[i] = A[i+1];
        A = B;
        nYuKunpeng--;
    }

    @Override
    public T first() {
        return A[0];
    }

    @Override
    public boolean isEmpty() {
        if  (nYuKunpeng == 0){
            System.out.println("此栈为空");
            return true;
        }
        else {
            System.out.println("此栈不为空");
            return false;
        }
    }

    @Override
    public int size() {
        return nYuKunpeng;
    }

    public void sort(){
       for(int i=0;i<size();i++) {
           for (int j = i; j > 0; j--) {
               if (Integer.parseInt(A[j-1] + "") > Integer.parseInt(A[j]+ "")) {
                   T temp = A[j];
                   A[j] = A[j - 1];
                   A[j - 1] = temp;
                }
            }
           System.out.println("此时元素为：" + toString()+ "元素的个数为" + size());
        }
    }

    public String toString(){

        String result = "";
        for (int i = 0;i <nYuKunpeng;i++){
            result += A[i]+ " ";
        }


        return result;
    }
}
