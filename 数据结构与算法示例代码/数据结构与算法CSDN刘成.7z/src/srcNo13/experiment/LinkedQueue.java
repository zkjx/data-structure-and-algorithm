package srcNo13.experiment;


import srcNo12.PP4_2.LinearNode;
import srcNo13.exceptions.EmptyCollectionException;
import srcNo13.pp5_1.QueueADT;

import javax.sound.sampled.Line;


public class LinkedQueue<T> implements QueueADT<T> {

    private int nYuKunpeng;
    private LinearNode<T> head, tail;

    public LinkedQueue(){
        nYuKunpeng = 0;
        head = tail = null;
    }

    @Override
    public void enqueue(T element) {
        LinearNode<T> node = new LinearNode<T>(element);

        if(isEmpty())
            head = node;
        else
            tail.setNext(node);
        tail = node;
        nYuKunpeng ++;

    }

    @Override
    public T dequeue() throws EmptyCollectionException {
       if(isEmpty())
           throw new EmptyCollectionException("queue");

       T result = head.getElement();
       head = head.getNext();
        nYuKunpeng --;

       if(isEmpty())
           tail = null;

       return result;
    }

    public void insert(T element1, int A){
        LinearNode<T> node1 = new LinearNode<T>(element1);
        LinearNode<T> current = head;

        if(A==0){
            node1.setNext(current);
            head = node1;
        }
        else{
            for(int i = 1; i < A; i ++)
                current = current.getNext();
            node1.setNext(current.getNext());
            current.setNext(node1);
        }

        nYuKunpeng++;



    }

    public void delete(int A){
        LinearNode current, temp = null;
        current = head;

        if( A == 0)
            head = head.getNext();
        else{
            for(int i = 0; i < A; i ++) {
                temp = current;
                current = current.getNext();
            }
            temp.setNext(current.getNext());
        }

        nYuKunpeng --;
    }


    public void sort(){
        LinearNode current, temp;
        int m = nYuKunpeng, n = 0;
        for(current = head; current.getNext() != null; current = current.getNext()){
            for(int i = 0; i < n; i ++){

            }
        }



    }

    @Override
    public T first() {
        return head.getElement();
    }

    @Override
    public boolean isEmpty() {
        if (nYuKunpeng == 0)
            return true;
        else
            return false;
    }

    @Override
    public int size() {
        return nYuKunpeng;
    }

    public String toString(){
        String result = "";
        LinearNode<T> current = head;
        int a = nYuKunpeng;
        while(a > 0) {
            result += current.getElement()+ ",";
            current = current.getNext();
            a--;
        }

        return result;
    }

}
