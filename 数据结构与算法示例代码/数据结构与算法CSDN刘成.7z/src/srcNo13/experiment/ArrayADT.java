package srcNo13.experiment;

public interface ArrayADT<T> {
    public void add(T element);
    public T delete();
    public T first();
    public boolean isEmpty();
    public int size();
    public String toString();
}
