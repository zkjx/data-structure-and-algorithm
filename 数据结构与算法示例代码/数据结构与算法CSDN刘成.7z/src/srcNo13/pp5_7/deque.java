package srcNo13.pp5_7;


import srcNo12.exceptions.EmptyCollectionException;

public class deque<T> implements QueueADT<T> {

    private int count;
    private LinearNode<T> head, tail;

    public deque(){
        count = 0;
        head = tail = null;
    }
    @Override
    public void enqueueFirst(T element) {
        LinearNode<T> node = new LinearNode<T>(element);

        if (isEmpty()) {
            tail = node;
        } else {
            head.setPrevious(node);
        }
        node.setNext(head);
        head = node;
        count++;

    }

    @Override
    public void enqueueLast(T element) {
        LinearNode<T> node = new LinearNode<T>(element);

        if (isEmpty()) {
            head = node;
        } else {
            tail.setNext(node);
        }
        node.setPrevious(tail);
        tail = node;
        count++;


    }

    @Override
    public T dequeueFirst() throws EmptyCollectionException {
        if (isEmpty())
            throw new srcNo13.exceptions.EmptyCollectionException("queue");
        LinearNode<T> temp = head;
        head = head.getNext();
        if (head != null) {
            head.setPrevious(null);
        } else {
            tail = null;
        }
        count--;
        return temp.getElement();

    }


    @Override
    public T dequeueLast() throws EmptyCollectionException{
        if (isEmpty())
            throw new srcNo13.exceptions.EmptyCollectionException("queue");
        LinearNode<T> temp = tail;
        tail = tail.getPrevious();
        if (tail != null) {
            tail.setNext(null);
        } else {
            head = null;
        }
        count--;
        return temp.getElement();

    }

    @Override
    public T first() throws EmptyCollectionException {
        if(isEmpty())
            throw new srcNo13.exceptions.EmptyCollectionException("queue");

        return head.getElement();
    }

    @Override
    public T Last() throws EmptyCollectionException {
        if(isEmpty())
            throw new srcNo13.exceptions.EmptyCollectionException("queue");

        return tail.getElement();
    }

    @Override
    public boolean isEmpty() {
        if (count == 0)
            return true;
        else
            return false;
    }

    @Override
    public int size() {
        return count;
    }

    public String toString(){
        String result = "";
        LinearNode<T> current = head;
        int a = count;
        while(a > 0) {
            result += current.getElement()+ " ";
            current = current.getNext();
            a--;
        }

        return result;
    }
}
