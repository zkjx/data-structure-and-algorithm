package srcNo13.pp5_7;

public class test {
    public static void main(String[] args) {
        deque dq = new deque();
        dq.enqueueFirst(1);
        dq.enqueueFirst(2);
        dq.enqueueLast(3);
        dq.enqueueLast(4);
        System.out.println("该队列内的元素" + dq);
        dq.enqueueLast( 5);
        dq.dequeueFirst();
        dq.dequeueLast();
        System.out.println("该队列内的元素"+ dq);
        System.out.println("该队列的长度"+ dq.size());
        System.out.println("该队列的头元素"+ dq.first());
        System.out.println("该队列的尾元素" + dq.Last());


    }
}
