package srcNo13.pp5_2;

public class test {
    public static void main(String[] args) {
        CircularArrayQueue caq = new CircularArrayQueue(2);
        caq.enqueue(1);
        caq.enqueue(2);
        caq.enqueue(3);
        System.out.println(caq.toString());
        caq.dequeue();
        System.out.println(caq.toString());
        System.out.println(caq.size());
        System.out.println(caq.first());
    }
}
