package srcNo13.yanghui;

import java.util.Scanner;

public class yanghuiTriangle {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        CircularArrayQueue caq = new CircularArrayQueue();
        System.out.println("请输入杨辉三角的行数");
        int n = scan.nextInt();
        caq.enqueue(0);
        caq.enqueue(1);
        int i = 0;
        while( i <= n){
            int x = Integer.parseInt(caq.dequeue() + "");
            int y = Integer.parseInt(caq.first() + "");
            if(x == 0){
                i ++;
                caq.enqueue(0);
            }
            caq.enqueue(x + y);
            if(x == 0){
                System.out.println();
                for(int j = 0; j < (n - i); j ++)
                    System.out.print(" ");
            }else
                System.out.print(x + " ");
        }
    }
}

