package srcNo13.pp5_1;


public class test {
    public static void main(String[] args) {
        LinkedQueue que = new LinkedQueue();
        que.enqueue(1);
        que.enqueue(2);
        que.enqueue(3);
        System.out.println(que.size());
        System.out.println(que.dequeue());
        System.out.println(que.toString());
        System.out.println(que.first());
    }
}
