package srcNo13.pp5_1;


import srcNo12.PP4_2.LinearNode;
import srcNo13.exceptions.EmptyCollectionException;


public class LinkedQueue<T> implements QueueADT<T> {

    private int count;
    private LinearNode<T> head, tail;

    public LinkedQueue(){
        count = 0;
        head = tail = null;
    }

    @Override
    public void enqueue(T element) {
        LinearNode<T> node = new LinearNode<T>(element);

        if(isEmpty())
            head = node;
        else
            tail.setNext(node);
        tail = node;
        count ++;

    }

    @Override
    public T dequeue() throws EmptyCollectionException {
       if(isEmpty())
           throw new EmptyCollectionException("queue");

       T result = head.getElement();
       head = head.getNext();
       count --;

       if(isEmpty())
           tail = null;

       return result;
    }

    @Override
    public T first() {
        return head.getElement();
    }

    @Override
    public boolean isEmpty() {
        if (count == 0)
            return true;
        else
            return false;
    }

    @Override
    public int size() {
        return count;
    }

    public String toString(){
        String result = "";
        LinearNode<T> current = head;
        int a = count;
        while(a > 0) {
            result += current.getElement()+ " ";
            current = current.getNext();
            a--;
        }

        return result;
    }
}
