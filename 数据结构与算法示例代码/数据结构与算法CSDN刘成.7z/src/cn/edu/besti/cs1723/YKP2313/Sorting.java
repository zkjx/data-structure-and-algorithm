package cn.edu.besti.cs1723.YKP2313;

public class Sorting {
    public static <T extends Comparable<T>> String insertionSort(T[] data)
    {
        for (int index = 1; index < data.length; index++)
        {
            T key = data[index];
            int position = index;

            // shift larger values to the right
            while (position > 0 && data[position-1].compareTo(key) > 0)
            {
                data[position] = data[position-1];
                position--;
            }

            data[position] = key;
        }

        String result="";

        for(int i=0;i<data.length;i++){
            result += data[i]+" ";
        }
        return result;
    }
}
