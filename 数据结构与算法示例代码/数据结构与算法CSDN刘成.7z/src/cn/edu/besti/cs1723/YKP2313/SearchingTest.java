package cn.edu.besti.cs1723.YKP2313;

import junit.framework.TestCase;
import org.junit.Test;
import srcNo20.Searching;

public class SearchingTest extends TestCase {

    @Test
    public void testLinearSearch() throws Exception{
        Comparable cpb[] = { 20,18,11,19,2313};//正常
        assertEquals(true,Searching.linearSearch(cpb,0,4,20));//边界
        assertEquals(true,Searching.linearSearch(cpb,0,4,2313));//边界
        assertEquals(true,Searching.linearSearch(cpb,0,4,18));//正常
        assertEquals(false,Searching.linearSearch(cpb,0,4,100));//异常


        Comparable cpb2[] = {1, 2, 3, 4, 5};//正序
        assertEquals(true,Searching.linearSearch(cpb2,0,4,1));//边界
        assertEquals(true,Searching.linearSearch(cpb2,0,4,5));//边界
        assertEquals(true,Searching.linearSearch(cpb2,0,4,3));//正常
        assertEquals(false,Searching.linearSearch(cpb2,0,4,100));//异常

        Comparable cpb3[] = {5, 4, 3, 2, 1};//倒序
        assertEquals(true,Searching.linearSearch(cpb3,0,4,1));//边界
        assertEquals(true,Searching.linearSearch(cpb3,0,4,5));//边界
        assertEquals(true,Searching.linearSearch(cpb3,0,4,3));//正常
        assertEquals(false,Searching.linearSearch(cpb3,0,4,100));//异常

        Comparable cpb4[] = {"B" , "C", "G", "A", "E"};//正常
        assertEquals(true,Searching.linearSearch(cpb4,0,4,"B"));//边界
        assertEquals(true,Searching.linearSearch(cpb4,0,4,"E"));//边界
        assertEquals(true,Searching.linearSearch(cpb4,0,4,"G"));//正常
        assertEquals(false,Searching.linearSearch(cpb4,0,4,"Z"));//异常

        Comparable cpb5[] = {"A" , "B", "C", "D", "E"};//正序
        assertEquals(true,Searching.linearSearch(cpb5,0,4,"A"));//边界
        assertEquals(true,Searching.linearSearch(cpb5,0,4,"E"));//边界
        assertEquals(true,Searching.linearSearch(cpb5,0,4,"C"));//正常
        assertEquals(false,Searching.linearSearch(cpb5,0,4,"Z"));//异常

        Comparable cpb6[] = {"E", "D", "C", "B", "A"};//倒序
        assertEquals(true,Searching.linearSearch(cpb6,0,4,"A"));//边界
        assertEquals(true,Searching.linearSearch(cpb6,0,4,"E"));//边界
        assertEquals(true,Searching.linearSearch(cpb6,0,4,"C"));//正常
        assertEquals(false,Searching.linearSearch(cpb6,0,4,"Z"));//异常

    }

}