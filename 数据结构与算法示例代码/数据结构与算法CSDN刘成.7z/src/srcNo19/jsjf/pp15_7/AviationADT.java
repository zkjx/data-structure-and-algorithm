package srcNo19.jsjf.pp15_7;

import srcNo19.jsjf.GraphADT;
public interface AviationADT<T> extends GraphADT<T>
{

    public void addEdge(T vertex1, T vertex2, double weight);

    public double shortestPathWeight(T vertex1, T vertex2);
}
