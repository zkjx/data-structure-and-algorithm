package srcNo19.jsjf.pp15_7;

public class test {
    public static void main(String[] args) {
        AviationNet a =new AviationNet();
        a.addVertex("A");
        a.addVertex("B");
        a.addVertex("C");
        a.addVertex("D");
        a.addEdge("A","B",100);
        a.addEdge("A","C",150);
        a.addEdge("A","D",50);
        a.addEdge("B","C",25);
        a.addEdge("B","D",50);
        System.out.println(a.toString());
        System.out.println("从A到C的最短路径为"+a.shortestPathLength("A","C"));
        System.out.println("从A到C的最短路径为"+a.shortestPathLength("A","D"));

        System.out.println("是否为连通的："+ a.isConnected());
        System.out.println("从A到C最小花费"+a.shortestPathWeight("A","C"));
        System.out.println("从A到D最小花费"+a.shortestPathWeight("A","D"));
    }
}
