package srcNo19.jsjf.pp15_1;

import java.util.ArrayList;

public class VertexNode<T> {
    public T element;
    public VertexNode<T> next;


    public VertexNode(T element)  // constructor
    {
        this.element = element;
        next = null;
    }


    //为节点添加邻接点
    public void setNext(VertexNode<T> ver){
        next = ver;
    }

    public VertexNode<T> getNext(){
        return next;
    }

    public T getElement(){
        return element;
    }


}
