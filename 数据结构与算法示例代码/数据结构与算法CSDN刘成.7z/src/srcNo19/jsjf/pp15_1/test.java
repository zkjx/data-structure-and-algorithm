package srcNo19.jsjf.pp15_1;

import java.util.Iterator;

public class test {
    public static void main(String[] args) {
        AlGraph ag = new AlGraph();
        ag.addVertex(1);
        ag.addVertex(2);
        ag.addVertex(3);
        ag.addVertex(4);
        ag.addVertex(5);
        ag.addEdge(1,2);
        ag.addEdge(1,3);
        ag.addEdge(2,4);
        ag.addEdge(3,5);
//        ag.removeEdge(1,3);
        System.out.println(ag.getIndex(1));
        System.out.println(ag.getIndex(2));

       ag.printNodeList();

        Iterator it1 = ag.iteratorDFS(0);
        while(it1.hasNext())
            System.out.print(it1.next()+" ");
        System.out.println();

        Iterator it2 = ag.iteratorBFS(0);
        while(it2.hasNext())
            System.out.print(it2.next() + " ");
        System.out.println();

        Iterator it3 = ag.iteratorShortestPath(0,3);
        while(it3.hasNext())
            System.out.print(it3.next()+" ");
        System.out.println();

        System.out.println(ag.isEdge(0,1));
        System.out.println(ag.isEdge(1,2));
    }
}
