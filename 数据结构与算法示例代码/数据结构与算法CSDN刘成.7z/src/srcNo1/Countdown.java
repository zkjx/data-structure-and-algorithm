public class Countdown
{
    public static void main(String[] args)
    {
        System.out.println("Three...");
        System.out.println("Two...");
        System.out.println("One...");
        System.out.println("zero...");
        System.out.println("Liftoff..."); // appears on first output line
        System.out.println("Houston, we have a problem.");
    }
}

