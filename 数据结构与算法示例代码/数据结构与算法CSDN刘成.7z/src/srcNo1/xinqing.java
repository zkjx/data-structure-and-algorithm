package srcNo1;

public class xinqing {
    public static void main(String[] args) {
        System.out.println("kaixin");
    }
}
