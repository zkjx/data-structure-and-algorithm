package srcNo1;

public class zxc {
    public static void main(String[] args) {
        int A;
        A = 20172313 % 6;
        System.out.println(A);
    }

}
