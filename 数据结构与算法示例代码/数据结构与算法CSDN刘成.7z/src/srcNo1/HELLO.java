package srcNo1;

public class HELLO {
    public static void main(String[] args) {
    System.out.println("HELLO");
}
}
