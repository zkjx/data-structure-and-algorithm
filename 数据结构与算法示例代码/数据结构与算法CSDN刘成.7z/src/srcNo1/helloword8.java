package srcNo1;

import java.util.Scanner;

public class helloword8 {
    public static void main(String[] args) {
        System.out.println("helloworld");
    }
}
