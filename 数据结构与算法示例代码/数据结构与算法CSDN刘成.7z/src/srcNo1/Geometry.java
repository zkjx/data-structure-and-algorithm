public class Geometry
{
  //----------------------------------------------------------
  //  Prints the number of sides of several geometric shapes.
  //----------------------------------------------------------
  public static void main(String[] args)
  {
     int sides = 7; 
     System.out.println("A heptagon has " + sides + "sides.");

     sides = 10;
     System.out.println("A decagon has " + sides + "sides.");

     sides =12;
     System.out.println("A dodecagon has " + sides + "sides.");
   }
}

