package srcNo11;

import java.util.*;
import java.text.NumberFormat;

public class MyDC {
    public char[] op = {'+','-','*','/','(',')'};
    public String[] strOp = {"+","-","*","/","(",")"};
    public boolean isDigit(char c){
        if(c>='0'&&c<='9'){
            return true;
        }
        return false;
    }
    public boolean isOp(char c){
        for(int i=0;i<op.length;i++){
            if(op[i]==c){
                return true;
            }
        }
        return false;
    }
    public boolean isOp(String s){
        for(int i=0;i<strOp.length;i++){
            if(strOp[i].equals(s)){
                return true;
            }
        }
        return false;
    }
    public List<String> cut(String str){
        List<String> list = new ArrayList<String>();
        StringTokenizer st = new StringTokenizer(str);
        while (st.hasMoreTokens()) {
            list.add(st.nextToken());
        }

        return list;
    }

    /**
     * 后缀表达式计算
     */
    public double doCal(List<String> list){
        Stack<Double> stack = new Stack<Double>();
        for(int i=0;i<list.size();i++){
            String s = list.get(i);
            double t=0;
            if(!isOp(s)){
                t = Double.parseDouble(s);
                stack.push(t);
            }else{
                if(s.equals("+")){
                    double a1 = (double)stack.pop();
                    double a2 = (double)stack.pop();
                    double v = a2+a1;
                    stack.push(v);
                }else if(s.equals("-")){
                    double a1 = (double)stack.pop();
                    double a2 = (double)stack.pop();
                    double v = a2-a1;
                    stack.push(v);
                }else if(s.equals("*")){
                    double a1 = (double)stack.pop();
                    double a2 = (double)stack.pop();
                    double v = a2*a1;
                    stack.push(v);
                }else if(s.equals("/")){
                    double a1 = (double)stack.pop();
                    double a2 = (double)stack.pop();
                    double v = a2/a1;
                    stack.push(v);
                }
            }
        }
        return stack.pop();
    }
    public String T(int a, int b){
        double t = (double)a/b;
        NumberFormat fmt;
        fmt = NumberFormat.getPercentInstance();
        System.out.println("正确率:"+fmt.format(t));
        return fmt.format(t);
    }


}
