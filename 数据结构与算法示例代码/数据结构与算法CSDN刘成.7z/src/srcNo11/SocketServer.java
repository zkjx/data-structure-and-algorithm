package srcNo11;

import srcNo8.Sorting;
import srcNo8.Sorting2;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;


/**
 * Created by besti on 2018/6/11.
 */
public class SocketServer {
    public static void main(String[] args) throws Exception {
        String p = "", str2 = "", str3 = "", ba = "",tf="";
        //1.建立一个服务器Socket(ServerSocket)绑定指定端口
        ServerSocket serverSocket = new ServerSocket(8800);
        //2.使用accept()方法阻止等待监听，获得新连接
        Socket socket = serverSocket.accept();
        //3.获得输入流
        InputStream inputStream = socket.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
        //获得输出流
        OutputStream outputStream = socket.getOutputStream();
        PrintWriter printWriter = new PrintWriter(outputStream);
        //4.读取用户输入信息
        String info1,info2,info3 = null;
        double result = 0;
        String[] str = new String[3];



        if (!((info1 = bufferedReader.readLine()) == null)) {
            System.out.println("我是服务器，收到的密文为：" + info1);

            str[0] = info1;
        }


            if (!((info2 = bufferedReader.readLine()) == null)) {
                str[1] = info2;
            }

        if (!((info3 = bufferedReader.readLine()) == null)) {
//            String info1 =new String(info.getBytes("GBK"),"utf-8");

            str[2] = info3;


        }

            DigestPass dig = new DigestPass(str[0]);
            String dp = dig.getResult();

            ArrayList A = new ArrayList();
            StringTokenizer st = new StringTokenizer(str[0]);
            while (st.hasMoreTokens()) {
                A.add(st.nextToken());
            }
            byte[] b = new byte[A.size()];
            for (int i = 0; i < A.size(); i++)
                b[i] = Byte.parseByte(A.get(i).toString());
//            int[] B = new int[A.size()];
//            int[] C = new int[A.size()];
//            for (int i = 0;i<A.size();i++){
//                B[i] = Integer.parseInt(A.get(i).toString());
//            }
//            Sort so = new Sort();
//            C = so.selectionSort(B);
//            for (int i = 0;i<C.length;i++)
//                result += C[i] + " ";

            FileOutputStream f2 = new FileOutputStream("SEnc.dat");
            f2.write(b);



        FroBtoA BA = new FroBtoA(info1);
        ba = BA.getR();
        System.out.println("解密后的密文为");
        System.out.println(ba);
        String str4 = BA.getR();
        DigestPass dig2 = new DigestPass(str4);
        String dp2 = dig2.getResult();



            if(info3.equals(dp2)&&info2.equals(dp))
                tf ="MD5值相同";
            else
                tf ="MD5值不相同";










        MyDC dc = new MyDC();
        List<String>  Z = dc.cut(ba);
        result = dc.doCal(Z);


            //给客户一个响应
//        printWriter.write("you input is" + " "+ info+"\n");
            Double reply = result;
//        printWriter.write(reply+"");
            printWriter.write(tf+"\n"+result+"");
            printWriter.flush();
            //5.关闭资源
            printWriter.close();
            outputStream.close();
            bufferedReader.close();
            inputStream.close();
            socket.close();
            serverSocket.close();
        }
    }


