package srcNo11;

import java.io.*;
import java.security.*;
import java.util.ArrayList;
import javax.crypto.*;
public class SEnc{
    String str1="",str2="";
    ArrayList<Byte> A = new ArrayList<Byte>();
    public SEnc(String str)throws Exception{
        String s=str;
        FileInputStream f=new FileInputStream("key1.dat");
        ObjectInputStream b=new ObjectInputStream(f);
        Key k=(Key)b.readObject( );
        Cipher cp=Cipher.getInstance("AES");
        cp.init(Cipher.ENCRYPT_MODE, k);
        byte ptext[]=s.getBytes("UTF8");
        for(int i=0;i<ptext.length;i++){
            str1 += ptext[i] + " ";
        }
        System.out.println(str1);
        byte ctext[]=cp.doFinal(ptext);
        for(int i=0;i<ctext.length;i++){
            str2 += ctext[i] + " ";
            A.add(ctext[i]);

        }


        System.out.println(str2);
        FileOutputStream f2=new FileOutputStream("SEnc.dat");
        f2.write(ctext);
    }

    public String getStr2() {
        return str2;
    }
}
