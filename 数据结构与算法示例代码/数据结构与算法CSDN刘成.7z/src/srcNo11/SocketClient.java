package srcNo11;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.Socket;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.List;
import java.util.Scanner;

/**
 * Created by besti on 2018/6/11.
 */
public class SocketClient {
    public static void main(String[] args) throws Exception {
        String str1 = "", str2 = "",str3 = "",str4 = "",str5="";
        //1.建立客户端Socket连接，指定服务器位置和端口
        //Socket socket = new Socket("localhost",8080);
        Socket socket = new Socket("localhost",8800);

        //2.得到socket读写流
        OutputStream outputStream = socket.getOutputStream();
        //       PrintWriter printWriter = new PrintWriter(outputStream);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
        //输入流
        InputStream inputStream = socket.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
        //3.利用流按照一定的操作，对socket进行读写操作
        Scanner scan = new Scanner(System.in);

        System.out.println("请输入一个表达式：");
        str1 = scan.nextLine();
        MyBC bc= new MyBC();


        List<String> A =  bc.InfixToPostfix(bc.work(str1));
        for(int i=0;i<A.size();i++) {
            str2 += A.get(i) + " ";
            str4 += A.get(i);
        }
        System.out.println("表达式转为后缀为："+ str2);
//        SEnc nc = new SEnc(str2);
//        String info = new String(info1.getBytes("GBK"),"utf-8");
        //     printWriter.write(info);
        //     printWriter.flush();


        FroAtoB AB = new FroAtoB(str2);
        String r = AB.getP();
        System.out.println("加密后的密文为");
        System.out.println(r);

        str5 = AB.getP();
        System.out.println("明文的MD5值为");
        DigestPass dig1 = new DigestPass(str2);
        String dp1 = dig1.getResult();
        System.out.println("密文的MD5值为");
        DigestPass dig2 = new DigestPass(str5);
        String dp2 = dig2.getResult();



        outputStreamWriter.write(r +"\n"+dp2 +"\n" +dp1);
        outputStreamWriter.flush();
        socket.shutdownOutput();
        //接收服务器的响应
        String reply = null;
        while (!((reply = bufferedReader.readLine()) ==null)){
            System.out.println("接收服务器的信息为：" + reply);
        }
        //4.关闭资源
        bufferedReader.close();
        inputStream.close();
        outputStreamWriter.close();
        //printWriter.close();
        outputStream.close();
        socket.close();
    }
}
