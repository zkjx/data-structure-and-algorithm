package srcNo11;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.spec.SecretKeySpec;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.security.InvalidKeyException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class FroBtoA {
    String p = "",q ="",temp = "",r ="";
    SecretKeySpec k;
    Cipher cp = Cipher.getInstance("AES");
    public FroBtoA(String str) throws Exception {
        // 读取对方的DH公钥
        FileInputStream f1=new FileInputStream("Bpub.dat");
        ObjectInputStream b1=new ObjectInputStream(f1);
        PublicKey  pbk=(PublicKey)b1.readObject( );
        //读取自己的DH私钥
        FileInputStream f2=new FileInputStream("Apri.dat");
        ObjectInputStream b2=new ObjectInputStream(f2);
        PrivateKey prk=(PrivateKey)b2.readObject( );
        // 执行密钥协定
        KeyAgreement ka=KeyAgreement.getInstance("DH");
        ka.init(prk);
        ka.doPhase(pbk,true);
        //生成共享信息
        byte[ ] sb=ka.generateSecret();



        String s = str;
        SecretKeySpec k2 = new SecretKeySpec(sb,0,24,"AES");

        StringTokenizer st = new StringTokenizer(s);
        ArrayList A = new ArrayList();
        while (st.hasMoreTokens()) {
            A.add(st.nextToken());
        }

        byte[] c = new byte[A.size()];
        for (int i = 0; i < A.size(); i++) {
            temp += A.get(i).toString();
            c[i] = Byte.parseByte(A.get(i).toString());

        }
        byte b[]=temp.getBytes("UTF8");

        cp.init(Cipher.ENCRYPT_MODE,k2);
        byte ptext[] = temp.getBytes("UTF8");
        byte ctext[] = cp.doFinal(ptext);
        System.out.println();
        for(int i = 0;i<ctext.length;i++)
            p += (ctext[i] +" ");

        k=new  SecretKeySpec(sb,"AES");

        // 解密

//        byte[] b = new byte[A.size()];

        cp.init(Cipher.DECRYPT_MODE, k2);
        byte ctext2[]=cp.doFinal(c);
        // 显示明文
        for(int i = 0;i<ctext2.length;i++) {
            q += (char) ctext2[i] + " ";
            r += (char) ctext2[i];
        }

    }

    public String getP() {
        return p;
    }

    public String getQ() {
        return q;
    }

    public String getR() {
        return r;
    }
}