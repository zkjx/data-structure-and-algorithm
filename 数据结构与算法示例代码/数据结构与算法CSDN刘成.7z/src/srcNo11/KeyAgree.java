package srcNo11;

import java.io.*;
import java.math.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.crypto.interfaces.*;

public class KeyAgree{
    public static void main(String args[ ]) throws Exception{
        // 读取对方的DH公钥
        FileInputStream f1=new FileInputStream(args[0]);
        ObjectInputStream b1=new ObjectInputStream(f1);
        PublicKey  pbk=(PublicKey)b1.readObject( );
//读取自己的DH私钥
        FileInputStream f2=new FileInputStream(args[1]);
        ObjectInputStream b2=new ObjectInputStream(f2);
        PrivateKey  prk=(PrivateKey)b2.readObject( );
        // 执行密钥协定
        KeyAgreement ka=KeyAgreement.getInstance("DH");
        ka.init(prk);
        ka.doPhase(pbk,true);
        //生成共享信息
        byte[ ] sb=ka.generateSecret();
        for(int i=0;i<sb.length;i++){
            System.out.print(sb[i]+",");
        }

        String s = "2"+"2"+"+"+"1"+"-";
        SecretKeySpec k2 = new SecretKeySpec(sb,0,24,"AES");
        Cipher cp = Cipher.getInstance("AES");
        cp.init(Cipher.ENCRYPT_MODE,k2);
        byte ptext[] = s.getBytes("UTF8");
        byte ctext[] = cp.doFinal(ptext);
        System.out.println();
        for(int i = 0;i<ctext.length;i++)
            System.out.print(ctext[i] +" ");


        SecretKeySpec k=new  SecretKeySpec(sb,"AES");
    }
}
