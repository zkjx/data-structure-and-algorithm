package srcNo11;

import java.io.UnsupportedEncodingException;
import java.security.*;
public class DigestPass{
    String result="";
    public DigestPass(String str) throws Exception {
        String x=str;
        MessageDigest m=MessageDigest.getInstance("MD5");
        m.update(x.getBytes("UTF8"));
        byte s[ ]=m.digest( );
        for (int i=0; i<s.length; i++){
            result+=Integer.toHexString((0x000000ff & s[i]) |
                    0xffffff00).substring(6);
        }
        System.out.println(result);
    }

    public String getResult() {
        return result;
    }
}
