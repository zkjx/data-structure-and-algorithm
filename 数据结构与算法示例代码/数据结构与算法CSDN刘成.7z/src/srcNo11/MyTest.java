package srcNo11;

import java.util.*;

public class MyTest {
    public static void main(String[] args) {
        String str1 = "",str2 = "";

        MyBC bc = new MyBC();
        MyDC dc = new MyDC();
        Scanner scan = new Scanner(System.in);

        System.out.println("请输入一个表达式：");
        str1 = scan.nextLine();
        List<String> A =  bc.InfixToPostfix(bc.work(str1));
        for(int i=0;i<A.size();i++)
            str2 += A.get(i) + " ";
        System.out.println("表达式转为后缀为："+ str2);
        System.out.println("该表达式求值为："+ dc.doCal(bc.InfixToPostfix(bc.work(str1))));


    }
}
