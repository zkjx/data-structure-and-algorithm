package srcNo14.pp6_8;

public class test2 {
    public static void main(String[] args) {
        ArrayUnorderedList aol = new ArrayUnorderedList(10);
        aol.addToFront(1);
        aol.addToRear(2);
        aol.addToRear(3);
        aol.addAfter(5,3);
        System.out.println(aol);
        aol.addAfter(4,3);
        System.out.println(aol);
        System.out.println("The first is " + aol.first());
        System.out.println("The last is " + aol.last());
        System.out.println("The size is " + aol.size());
        aol.remove(3);
        System.out.println(aol.contains(3));
        System.out.println(aol.contains(1));
        aol.removeFirst();
        aol.removeLast();
        System.out.println(aol);
    }
}
