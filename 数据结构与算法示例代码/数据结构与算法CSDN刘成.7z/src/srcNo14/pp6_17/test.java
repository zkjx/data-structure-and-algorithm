package srcNo14.pp6_17;

public class test {
    public static void main(String[] args) {
        Course course1 = new Course("CS", 101, "Introduction to Programming", "A-");
        Course course2 = new Course("ARCH", 305, "Building Analysis", "A");
        Course course3 = new Course("GER", 210, "Intermediate German");
        Course course4 = new Course("CS", 320, "Computer Architecture");
        Course course5 = new Course("THE", 201, "The Theatre Experience");
        Course course6 = new Course("AHQ", 202, "The Theatre Experience ");
        LinkedOrderedList lol = new LinkedOrderedList();
        lol.addCourse(course1);
        lol.addCourse(course2);
        lol.addCourse(course3);
        lol.addCourse(course4);
        lol.addCourse(course5);
        lol.addCourse(course6);
        System.out.println(lol);
        System.out.println("--------------------------------------------------------------------------");
//        System.out.println(lol.first());
//        System.out.println(lol.last());
        System.out.println("--------------------------------------------------------------------------");
        lol.removeFirst();
        lol.removeLast();
        lol.remove(course4);
        System.out.println(lol);
        System.out.println(lol.contains(course1));
        System.out.println(lol.contains(course2));
        System.out.println(lol.contains(course3));
        System.out.println(lol.contains(course4));
        System.out.println(lol.contains(course5));
        System.out.println(lol.contains(course6));

    }
}
