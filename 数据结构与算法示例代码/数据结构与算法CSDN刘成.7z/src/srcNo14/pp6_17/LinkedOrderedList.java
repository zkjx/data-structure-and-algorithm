package srcNo14.pp6_17;
import srcNo14.exceptions.ElementNotFoundException;
import srcNo14.exceptions.EmptyCollectionException;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;


public class LinkedOrderedList implements Iterable<Course> {
    protected int count;
    protected LinearNode<Course> head, tail;
    protected int modCount;


    public LinkedOrderedList() {
        count = 0;
        head = tail = null;
        modCount = 0;
    }

    public Course removeFirst() throws EmptyCollectionException {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");

        LinearNode<Course> current = head;
        head = head.getNext();
        count--;
        modCount++;
        return current.getElement();
    }

    public Course removeLast() throws EmptyCollectionException {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");

        LinearNode<Course> current = head;
        while (current.getNext() != tail)
            current = current.getNext();
        Course temp = current.getNext().getElement();
        current.setNext(null);
        tail = current;
        count--;
        modCount++;
        return temp;
    }


    public Course remove(Course targetElement) throws EmptyCollectionException,
            ElementNotFoundException {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");

        boolean found = false;
        LinearNode<Course> previous = null;
        LinearNode<Course> current = head;

        while (current != null && !found)
            if (targetElement.equals(current.getElement()))
                found = true;
            else {
                previous = current;
                current = current.getNext();
            }

        if (!found)
            throw new ElementNotFoundException("LinkedList");

        if (size() == 1)
            head = tail = null;
        else if (current.equals(head))
            head = current.getNext();
        else if (current.equals(tail)) {
            tail = previous;
            tail.setNext(null);
        } else
            previous.setNext(current.getNext());

        count--;
        modCount++;

        return current.getElement();
    }

    public Course first() throws EmptyCollectionException {
        return head.getElement();
    }


    public Course last() throws EmptyCollectionException {
        return tail.getElement();
    }

    public boolean contains(Course targetElement) throws
            EmptyCollectionException {
        if (isEmpty())
            throw new EmptyCollectionException("LinkedList");

        boolean found = false;
        LinearNode<Course> previous = null;
        LinearNode<Course> current = head;

        while (current != null && !found)
            if (targetElement.equals(current.getElement()))
                found = true;
            else {
                previous = current;
                current = current.getNext();
            }

        if (!found)
            return false;
        else
            return true;
    }

    public void addCourse(Course course) {
        LinearNode<Course> temp = new LinearNode(course);
        LinearNode<Course> previous = null;
        LinearNode<Course> current = head;
        while(current != null && course.compareTo(current.getElement())> 0){
            previous = current;
            current = current.getNext();
        }
        if(previous == null){
            head = tail =  temp;
        }
        else{
            previous.setNext(temp);
        }
        temp.setNext(current);
        if(temp.getNext() == null)
            tail = temp;


        count++;
        modCount++;

    }

    public String toString()
    {
        int n = count;
        String result = "";
        LinearNode<Course> current = head;
        while(n > 0){
            result += current.getElement()+"\n";
            current = current.getNext();
            n--;
        }
        return result;
    }

    public int size() {
        return count;
    }

    public boolean isEmpty() {
        if (count == 0)
            return true;
        else
            return false;
    }


    @Override
    public Iterator<Course> iterator() {
        return new LinkedListIterator();
    }

    private class LinkedListIterator implements Iterator<Course> {
        private int iteratorModCount;
        private LinearNode<Course> current;


        public LinkedListIterator() {
            current = head;
            iteratorModCount = modCount;
        }

        public boolean hasNext() throws ConcurrentModificationException {
            if (iteratorModCount != modCount)
                throw new ConcurrentModificationException();

            return (current != null);
        }


        public Course next() throws ConcurrentModificationException {
            if (!hasNext())
                throw new NoSuchElementException();

            Course result = current.getElement();
            current = current.getNext();
            return result;
        }


        public void remove() throws UnsupportedOperationException {
            throw new UnsupportedOperationException();
        }
    }
}

