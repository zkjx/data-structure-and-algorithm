package srcNo14.TextbookCode;


//public class LinkedUnorderedList<T> extends LinkedList<T>
//        implements UnorderedListADT<T>
//{
//
//    public LinkedUnorderedList()
//    {
//        super();
//    }
//
//
//    public void addToFront(T element)
//    {
//        // To be completed as a Programming Project
//    }
//
//
//    public void addToRear(T element)
//    {
//        // To be completed as a Programming Project
//    }
//
//
//
//    public void addAfter(T element, T target)
//    {
//        // To be completed as a Programming Project
//    }
//}
//
