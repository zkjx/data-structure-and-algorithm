package srcNo14.TextbookCode;


public interface OrderedListADT<T> extends ListADT<T>
{

    public void add(T element);
}
