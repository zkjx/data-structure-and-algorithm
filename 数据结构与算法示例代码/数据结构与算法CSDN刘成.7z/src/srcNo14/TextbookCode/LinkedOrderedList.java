package srcNo14.TextbookCode;


//public class LinkedOrderedList<T> extends LinkedList<T>
//        implements OrderedListADT<T>
//{
//
//    public LinkedOrderedList()
//    {
//        super();
//    }
//
//    public void add(T element)
//    {
//
//    }
//}
