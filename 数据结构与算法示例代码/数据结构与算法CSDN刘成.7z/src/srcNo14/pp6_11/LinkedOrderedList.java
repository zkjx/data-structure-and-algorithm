package srcNo14.pp6_11;

import srcNo14.exceptions.NonComparableElementException;

public class LinkedOrderedList<T> extends LinkedList<T>
{

    public LinkedOrderedList()
    {
        super();
    }


    public void add(T element)
    {
        LinearNode<T> temp = new LinearNode(element);
        LinearNode<T> previous = null;
        LinearNode<T> current = head;
        while(current != null && Integer.parseInt(element+"") > Integer.parseInt(current.getElement()+"")){
            previous = current;
            current = current.getNext();
        }
        if(previous == null){
            head = tail =  temp;
        }
        else{
            previous.setNext(temp);
        }
        temp.setNext(current);
        if(temp.getNext() == null)
            tail = temp;


        count++;
        modCount++;

    }
}
