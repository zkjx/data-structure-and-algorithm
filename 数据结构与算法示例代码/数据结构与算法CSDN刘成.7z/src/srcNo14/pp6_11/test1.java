package srcNo14.pp6_11;

public class test1 {
    public static void main(String[] args) {
        LinkedOrderedList aol = new LinkedOrderedList();
        aol.add(1);
        aol.add(2);
        aol.add(3);
        aol.add(5);
        System.out.println(aol);
        aol.add(4);
        System.out.println(aol);
        System.out.println("The first is " + aol.first());
        System.out.println("The last is " + aol.last());
        System.out.println("The size is " + aol.size());
        aol.remove(3);
        System.out.println(aol.contains(3));
        System.out.println(aol.contains(1));
        aol.removeFirst();
        aol.removeLast();
        System.out.println(aol);
    }
}
