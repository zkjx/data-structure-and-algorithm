//**************************************************************************************************
// pp7_4RationalNumberTest.java    Author:余坤澎
//
//**************************************************************************************************

public class pp7_4RationalNumberTest
{
    public static void main(String[] args)
    {   
        int i, j, k;

        pp7_4RationalNumber r1 = new pp7_4RationalNumber(6, 8);
        pp7_4RationalNumber r2 = new pp7_4RationalNumber(1, 9);
        pp7_4RationalNumber r3 = new pp7_4RationalNumber(1, 2);
        pp7_4RationalNumber r4 = new pp7_4RationalNumber(2, 4);

        i = r1.compareTo(r2);
        j = r2.compareTo(r3);
        k = r3.compareTo(r4);
        System.out.println(i + " " + j + " " + k);
    }
}
