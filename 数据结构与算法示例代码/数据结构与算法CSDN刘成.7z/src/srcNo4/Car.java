//*****************************************************************
// Car.java                Author: 余坤澎
//
//*****************************************************************

public class Car
{
    public String carchangname, carxinghao; 
    public int caryear, life;

    public Car(String A, String B, int C)
    {
        carchangname = A;
        carxinghao = B;
        caryear = C;
    }

    public void setCarchangname(String a)
    {
        carchangname = a;
    }

    public String getCarchangname()
    {
        return carchangname;
    }

    public void setCarxinghao(String b)
    {
        carxinghao = b;
    }

    public String getCarxinghao()
    {
        return carxinghao;
    }

    public void setCaryear(int c)
    {
        caryear = c;
    }

    public int getCaryear()
    {
        return caryear;
    }

    public String toString()
    {
        return carchangname + " " + carxinghao + " " + caryear;
    }

    public boolean isAntique()
    {
        life = 2018 - caryear;
        return ( life > 45 );
    }
}




