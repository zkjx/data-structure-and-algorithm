package srcNo4;
//******************************************************************************
// classpractice411.java                Author:余坤澎
//
//
//******************************************************************************

import java.util.Scanner;
import java.util.concurrent.Callable;

public class classpractice411 {
    public static void main(String[] args) {
        int A, B = 1, C, D = 1;

        Scanner scan = new Scanner(System.in);

        System.out.println("请输入一个数");
        A = scan.nextInt();

        for (; A > 0; A--) {
            B *= A;
        }
        System.out.println("该数的阶乘为:" + B);

        System.out.println("请再输入一个数");
        C = scan.nextInt();

        while (C > 0) {
            D *= C;
            C--;
        }
        System.out.println("该数的阶乘为:" + D);


    }

}
