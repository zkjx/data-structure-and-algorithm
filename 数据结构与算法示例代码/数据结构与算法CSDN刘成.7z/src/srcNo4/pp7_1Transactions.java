//**************************************************
// Transactions.java  Author
//**************************************************

public class pp7_1Transactions
{
//--------------------------------------------------------
// Creats some bank accounts and requests various services
//--------------------------------------------------------
public static void main(String[] args)
{
    pp7_1Account acct1 = new pp7_1Account("Ted Murphy", 72354);
    pp7_1Account acct2 = new pp7_1Account("Jane smith", 69713);
    pp7_1Account acct3 = new pp7_1Account("Edward Demsey", 93757);

    acct1.deposit(25.85);

    double smithBalance = acct2.deposit(500.00);
    System.out.println("smith balance after deposit: " + smithBalance);

    System.out.println("Smith balance after withdrawal: " + 
                        acct2.withdraw(430.75, 1.50));

    acct1.addInterest();
    acct2.addInterest();
    acct3.addInterest();

    System.out.println();
    System.out.println(acct1);
    System.out.println(acct2);
    System.out.println(acct3);
                                                                                                                                                }
}

