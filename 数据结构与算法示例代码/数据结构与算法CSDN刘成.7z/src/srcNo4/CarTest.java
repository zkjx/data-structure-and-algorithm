//***************************************************************
// CarTest.java   Author: 余坤澎
//
//***************************************************************

public class CarTest
{
    public static void main(String[] args)
    {   
        boolean z;

        Car car1 = new Car("BWM", "365", 2015);
        System.out.println(car1);

        car1.setCarchangname("falali");
        car1.getCarxinghao();
        System.out.println(car1);

        z = car1.isAntique();
        System.out.println(z);
    }
}
