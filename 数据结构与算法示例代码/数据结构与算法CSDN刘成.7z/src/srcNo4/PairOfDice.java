//*******************************************************************
// PairOfDice.java  Author:余坤澎
//
//*******************************************************************

public class PairOfDice
{
    private final int MAX = 6;

    private int faceValue1, faceValue2;

    public PairOfDice()
    {
        faceValue1 = 1;
        faceValue2 = 1;
    }

    public int roll1()
    {
        faceValue1 = (int)(Math.random() * MAX) + 1;
        return faceValue1;
    }

    public int roll2()
    {
        faceValue2 = (int)(Math.random() * MAX) + 1;
        return faceValue2;
    }


    public void setfaceValue1(int a)
    {
        faceValue1 = a;
    }

    public int getfaceValue1()
    {
        return faceValue1;
    }

    public void setfaceValue2(int b)
    {
        faceValue2 = b;
    }

    public int getfaceValue2()
    {
        return faceValue2;
    }

    public String back()
    {
        return Integer.toString(faceValue1 + faceValue2);
    }

}





