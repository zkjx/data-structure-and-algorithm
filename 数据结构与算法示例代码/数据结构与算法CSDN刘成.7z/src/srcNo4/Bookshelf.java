//**********************************************
// Bookshelf.java        Author:余坤澎
//**********************************************

public class Bookshelf
{
    public static void main(String[] args)
    {
        Book book1 = new Book("highmath", "ABC", "ZXC", "123");
        System.out.println(book1);

        Book book2 = new Book("英语", "老师", "**出版社", "2017.2.3");
        System.out.println(book2);  

        book1.setBookname("英语");
        book1.setAuthor("老师");
        book1.getPress();
        book1.getCopyrightdate();
        System.out.println(book1);
    }

}
