//***************************************************************
// RollingDice2.java  Author: 余坤澎
//***************************************************************

public class RollingDice2
{
    public static void main(String[] args)
    {
        PairOfDice die1, die2;
        String sum;

        die1 = new PairOfDice();
        die2 = new PairOfDice();

        die1.roll1();
        die1.roll2();
        die2.roll1();
        die2.roll2();
        sum = die1.back();
        System.out.println(sum);

        die1.setfaceValue1(4);
        die1.setfaceValue2(6);

        sum = die1.back();
        System.out.println(sum);
    }
}

