//*************************************************************
// RationalNumber.java Author
//
// Represents one rational number with a number with a numerator and 
// denominator
//*************************************************************

public class pp7_4RationalNumber implements Comparable<pp7_4RationalNumber>
{
    private int numerator, denominator;
    public double num1, num2;

//---------------------------------------------------------------
// Constructor: Sets up the rational number by rnsuring a nonzero 
// demonminator and making only the numerator signed
//---------------------------------------------------------------
    public pp7_4RationalNumber(int numer, int denom)
    {
        if (denom == 0)
            denom = 1;

// Make the numerator "store" the sign
        if (denom < 0)
            {
                numer = numer * -1;
                denom = numer * -1;
            }
                numerator = numer;
                denominator = denom;
                reduce();
    }
//--------------------------------------------------------------
// Returns the numerator of this rational number
//--------------------------------------------------------------
        public int getNumerator()
            {
                return numerator;
            }

//--------------------------------------------------------------
// Returns the denominator of this rational number
//--------------------------------------------------------------
        public int getDenominator()
            {
                return denominator;
            }

//--------------------------------------------------------------
// Returns the reciprocal of this rational number
//--------------------------------------------------------------
        public pp7_4RationalNumber reciprocal()
            {
                return new pp7_4RationalNumber(denominator, numerator);
            }

//--------------------------------------------------------------
// Adds this rational number to the one passed as a parameter
// A common denominator is found by multiplying th
// denominators
//--------------------------------------------------------------
        public pp7_4RationalNumber add(pp7_4RationalNumber op2)
            {
                int commonDenominator = denominator * op2.getDenominator();
                int numerator1 = numerator * op2.getDenominator();
                int numerator2 = op2.getNumerator() * denominator;
                int sum = numerator1 + numerator2;
                                                                                                        
                return new pp7_4RationalNumber(sum, commonDenominator);
            }

//--------------------------------------------------------------
// Subtracts the rational number passed as a parameter from this
// rational number
//--------------------------------------------------------------
        public pp7_4RationalNumber subtract(pp7_4RationalNumber op2)
            {
                int commonDenominator = denominator * op2.getDenominator();
                int numerator1 = numerator * op2.getDenominator();
                int numerator2 = op2.getNumerator() * denominator;
                int difference = numerator1 - numerator2;

                return new pp7_4RationalNumber(difference, commonDenominator);
            }

//--------------------------------------------------------------
// Multiplies this rational number by the one passed as a 
// parameter
//-------------------------------------------------------------
        public pp7_4RationalNumber multiply(pp7_4RationalNumber op2)
            {
                int numer = numerator * op2.getNumerator();
                int denom = denominator * op2.getDenominator();

                return new pp7_4RationalNumber(numer, denom);
            }
                            
//---------------------------------------------------------------
// Divides this rational number by the one passed as a parameter
// by multiplying by the reciprocal of the second rational
//---------------------------------------------------------------
        public pp7_4RationalNumber divide(pp7_4RationalNumber op2)
            {
                return multiply(op2.reciprocal());
            }

//---------------------------------------------------------------
// Determines if this rational number is equal to the one passed
// as a parameter. Assumes they are both reduced
//---------------------------------------------------------------
        public boolean isLike(pp7_4RationalNumber op2)
            {
                return ( numerator == op2.getNumerator() &&
                        denominator == op2.getDenominator() );
            }

//---------------------------------------------------------------
// Returns this rational number as a string
//---------------------------------------------------------------
        public String toString()
            {
                String result;
                if (numerator == 0)
                    result = "0";
                else
                   if (denominator == 1)
                        result = numerator + "";
                   else 
                        result = numerator + "/" + denominator;
                                                                                                    
                return result;
            }
         
//--------------------------------------------------------------
// Reduces this rational number by dividing both the numerator
// and the denominator by their greatest common divisor
//--------------------------------------------------------------
        private void reduce()
            {
                if (numerator != 0)
                {
                    int common = gcd(Math.abs(numerator), denominator);

                    numerator = numerator / common;
                    denominator = denominator / common;
                }
            }

//--------------------------------------------------------------
// Computes and returns the greatest common divisor of the two 
// positive parameters. Uses euclid's algorithm
//--------------------------------------------------------------
        private int gcd(int num1, int num2)
        {
                while (num1 != num2)
                    if (num1 > num2)
                        num1 = num1 - num2;
                    else 
                        num2 = num2 - num1;

                        return num1;
        }

        public int compareTo(pp7_4RationalNumber op2)
        {
            num1 = numerator * 1.0 / denominator * 1.0;
            num2 = op2.getNumerator() * 1.0 / op2.getDenominator() * 1.0;
            double num3 = -0.0001;

            if ( (num1 - num2) < 0.0001 &&
                (num1 - num2) > num3)
                return 0;
            else
                if ( (num1 - num2) > 0.0001)
                    return 1;
                else
                    return -1;
        }

            
}


