//****************************************************
// Book.java   Author:余坤澎
//****************************************************

public class Book
{
    public String bookname, author, press, copyrightdate;
    
    public Book(String bn, String ah, String pr, String crt)
    {
        bookname = bn;
        author = ah;
        press = pr;
        copyrightdate = crt;
    }

    public void setBookname(String A)
    {
        bookname = A;
    }

    public String getBookname()
    {
        return bookname;
    }

    public void setAuthor(String B)
    {
        author = B;
    }

    public String getAuthor()
    {
        return author;
    }

    public void setPress(String C)
    {
        press = C;
    }

    public String getPress()
    {
        return press;
    }

    public void setCopyrightdate(String D)
    {
        copyrightdate = D;
    }

    public String getCopyrightdate()
    {
        return copyrightdate;
    }

    public String toString()
    {
            return bookname + "\t" + author + "\t"    
                 + press + "\t" + copyrightdate;
    }
}



     
