#include <stdio.h>��
int main()
{int c1,c2;
 c1=197;
 c2=198;
 printf("c1=%c,c2=%c\n",c1,c2);
 printf("c1=%d��c2=%d\n",c1,c2);
 return 0;
} 


