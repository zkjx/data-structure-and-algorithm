#include<stdio.h>
int main()
{int max(int x,int y,int z);
 int a,b,c;
 printf("input three integer: ");
 scanf("%d,%d,%d",&a,&b,&c);
 printf("max=%d\n",max(a,b,c));
 return 0;
 }