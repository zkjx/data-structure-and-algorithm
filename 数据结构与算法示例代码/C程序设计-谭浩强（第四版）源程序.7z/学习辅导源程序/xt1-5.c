#include <stdio.h>
int main ( )
{  printf ("**************************\n\n");
   printf("        Very  Good!\n\n");
   printf ("**************************\n");
   return 0;
}

