#include <stdio.h>
int main()
{double a;
 a=10000/3.0;
 printf("%f\n",a);
 return 0;
}



