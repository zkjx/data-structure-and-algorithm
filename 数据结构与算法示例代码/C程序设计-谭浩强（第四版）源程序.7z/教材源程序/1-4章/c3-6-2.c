#include <stdio.h>
int main()
{double a=1.0;
 printf("%20.15f\n",a/3);
 return 0;
}


