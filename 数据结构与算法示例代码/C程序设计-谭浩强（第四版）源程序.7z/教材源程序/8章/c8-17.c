#include <stdio.h>
int main()
  {char *string="I love China!";
   printf("%s\n",string);
   return 0;
}
