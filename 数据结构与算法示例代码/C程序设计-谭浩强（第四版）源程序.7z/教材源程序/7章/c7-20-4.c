//#include <stdio.h>
void print_string(char str[])
{
 printf("%s\n",str);
}
