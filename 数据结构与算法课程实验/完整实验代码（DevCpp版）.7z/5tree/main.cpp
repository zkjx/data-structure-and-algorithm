#include "Menu.h"
int main()
{
	Menu<BinTree<char> > *menu = Menu<BinTree<char> >::getInstance();
	menu->mainMenu(); 
	return 0;
}
